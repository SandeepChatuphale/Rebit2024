import { Component, DoCheck } from '@angular/core';
import { RouterModule } from '@angular/router';
import { UserService } from '../../user/user.service';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-menu',
  imports: [RouterModule,CommonModule],
  templateUrl: './menu.component.html',
  styleUrl: './menu.component.css'
})
export class MenuComponent implements DoCheck {

    isLoggedIn = false;

    constructor(private service:UserService){}

    ngDoCheck(): void {
      this.isLoggedIn = this.service.isLoggedIn 
   }
}
