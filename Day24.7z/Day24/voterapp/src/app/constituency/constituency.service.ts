import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Constituency } from '../model/Constituency';

@Injectable({
  providedIn: 'root'
})
export class ConstituencyService {

  readonly BASE_URL = 'http://localhost'

  constructor(private http:HttpClient) { }

  findAll()
  {
    let token = sessionStorage.getItem('token')
          let myheader = new HttpHeaders()
                            .append('Authorization',`Bearer ${token}`)
    return this.http.get<Constituency[]>(`${this.BASE_URL}/cs/constituency`,{headers:myheader})
  }

}
