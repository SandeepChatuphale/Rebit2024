import { Component, DoCheck, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Voter } from '../../model/Voter';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-update',
  imports: [FormsModule,CommonModule],
  templateUrl: './update.component.html',
  styleUrl: './update.component.css'
})
export class UpdateComponent implements DoCheck{
  
  ngDoCheck(): void {
  
      //creating copy 
      this.v.id = this.voter.id
      this.v.name = this.voter.name
      this.v.age = this.voter.age
      this.v.gender = this.voter.gender
      this.v.constituencyName = this.voter.constituencyName
      this.v.constituencyId = this.voter.constituencyId
  }

  @Input()
  voter = new Voter(0,'',0,'','',0)

  @Output()
  voterEmitter = new EventEmitter<Voter>()

  v = new Voter(0,'',0,'','',0)


  performUpdate(e:Event)
  {
    e.preventDefault();
    this.voterEmitter.emit(this.v);
  }
}
