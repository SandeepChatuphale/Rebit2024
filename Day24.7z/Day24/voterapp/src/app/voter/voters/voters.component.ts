import { Component } from '@angular/core';
import { Voter } from '../../model/Voter';
import { CommonModule } from '@angular/common';
import { VoterService } from '../voter.service';
import { UpdateComponent } from '../update/update.component';

@Component({
  selector: 'app-voters',
  imports: [CommonModule,UpdateComponent],//CommonModule needed for ngFor
  templateUrl: './voters.component.html',
  styleUrl: './voters.component.css'
})
export class VotersComponent {

  allVoters : Voter[] = []
  showUpdate = false

  selectedVoter = new Voter(0,'',1,'','',0)

  //DI - injecting object of VoterService
  constructor(private service:VoterService){}

  showAll(){
    this.service.findAll().subscribe({
      next: success => {this.allVoters = success},
      error: error => {
        if(error.status == 403){
          console.log('Access Denied')
        }
      }
    })

  }

  deleteById(id:number)
  { 
  }

  update(existingVoter:Voter)
  {
    console.log(existingVoter)
    this.selectedVoter = existingVoter;
    this.showUpdate = true    
  }

  //this is called from child component when update button is 
  // clicked in child component
  doUpdate(updatedVoter:Voter)
  {
    this.showUpdate = false
    console.log(updatedVoter)

    
    //update DB by making REST call

  }

}
