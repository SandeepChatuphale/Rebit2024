import { Injectable, OnInit } from '@angular/core';
import { User } from '../model/User';
import { HttpClient } from '@angular/common/http';
import { TokenResponse } from '../model/TokenResponse';

@Injectable({
  providedIn: 'root'
})
export class UserService  {

  readonly BASE_URL = 'http://localhost'

  isLoggedIn = false;

  constructor(private http:HttpClient) { 
    let token = sessionStorage.getItem('token')
    this.isLoggedIn = token!=null;
  }
  
  authenticate(u:User)
  {
    //make a REST call
    const URL = this.BASE_URL + "/us/user/authentication"

    return this.http.post<TokenResponse>(URL,u)

    /*
    if(u.email == 'rebit' && u.password == 'rebit')
      return true;
    else
      return false;
    */
  }



  
}
