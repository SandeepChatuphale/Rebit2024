import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { VotersComponent } from './voter/voters/voters.component';
import { LoginComponent } from './user/login/login.component';
import { HeaderComponent } from './common/header/header.component';
import { FooterComponent } from './common/footer/footer.component';
import { RegisterComponent } from './voter/register/register.component';

@Component({
  selector: 'app-root',
  imports: [RouterOutlet,VotersComponent,LoginComponent,HeaderComponent,FooterComponent,RegisterComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'helloworld';
}
