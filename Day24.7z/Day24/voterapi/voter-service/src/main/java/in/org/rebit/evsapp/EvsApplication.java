package in.org.rebit.evsapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@SpringBootApplication
@EnableAspectJAutoProxy // enabling AOP support
@EnableFeignClients
public class EvsApplication {

	public static void main(String[] args) {

		SpringApplication.run(EvsApplication.class, args);
	}
}
