package in.org.rebit.emai.service.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.org.rebit.emai.service.entity.Email;
import in.org.rebit.emai.web.response.EmailResponse;

@RestController
@RequestMapping("/email")
public class EmailRestController {

	@Autowired
	private Environment env;
	
	
	@PostMapping
	public EmailResponse sendEmail(@RequestBody Email e)
	{
		System.out.println("email sent " + e);
		System.out.println("Email sent by service on port " + 
				env.getProperty("local.server.port"));
		EmailResponse res = new EmailResponse();
		res.setStatus(true); //
		return res;
	}
}
