package in.org.rebit.evsapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;

@SpringBootApplication
@EnableAspectJAutoProxy // enabling AOP support
@EnableMethodSecurity(prePostEnabled = true) //enabling method level security
public class EvsApplication {

	public static void main(String[] args) {

		SpringApplication.run(EvsApplication.class, args);
	}
}
