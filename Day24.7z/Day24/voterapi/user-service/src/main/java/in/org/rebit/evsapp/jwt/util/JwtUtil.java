package in.org.rebit.evsapp.jwt.util;

import java.util.Base64;
import java.util.Collection;
import java.util.Date;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

@Component
public class JwtUtil {
	
	//@Value("${jwt.token.duration}")
	private int expirationTime = 60 * 60 * 50 * 100;
	
	//@Value("${jwt.secret.key}")
	private String secretKey = "secret";

	public String generateToken(String username, Collection<? extends GrantedAuthority> authorities) {
		System.out.println("generateToken()");
		String jwtToken = "dummy token";

		String[] roles = new String[authorities.size()];

		//populating string array with authorities
		int i = 0;
		for (GrantedAuthority grantedAuthority : authorities) {
			roles[i] = grantedAuthority.getAuthority();
			i++;
		}

		// logic to generate token
		jwtToken = JWT.create()
					  .withClaim("USER_NAME", username)
					  .withArrayClaim("ROLES", roles)
					  .withExpiresAt(new Date(System.currentTimeMillis() + expirationTime))
					  .sign(Algorithm.HMAC256(this.secretKey));

		return jwtToken;
	}

	public String validateToken(String token) {
		System.out.println("In side validateToken()");

		String payload = JWT.require(Algorithm.HMAC256(this.secretKey))
							.build()
							.verify(token)
							.getPayload();

		byte[] decodedByteArray = Base64.getDecoder().decode(payload);
		String decodedPayload = new String(decodedByteArray);
		return decodedPayload;
	}
}
