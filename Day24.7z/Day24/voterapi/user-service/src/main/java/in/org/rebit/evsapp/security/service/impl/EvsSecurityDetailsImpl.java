package in.org.rebit.evsapp.security.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import in.org.rebit.evsapp.dao.EvsUserDao;
import in.org.rebit.evsapp.entity.EvsUser;
import in.org.rebit.evsapp.entity.Role;

@Service
public class EvsSecurityDetailsImpl implements UserDetailsService {

	@Autowired
	private EvsUserDao dao;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		System.out.println("In loadUserByUsername " + username);
		
		EvsUser evsUser = dao.findByEmail(username);
		
		//if user with given username NOT found
		if(evsUser == null)
			throw new UsernameNotFoundException(username);
		
		
		List<GrantedAuthority> authorities = new ArrayList<>();
		
		List<Role> roles = evsUser.getRoles();
		
		for (Role role : roles) {
			authorities.add(new SimpleGrantedAuthority(role.getAuthority()));
		}
				
		User authenticatedUser = new User(evsUser.getEmail(),
										  evsUser.getPassword(),
										  authorities);
		
		return authenticatedUser;
				
	}
}
