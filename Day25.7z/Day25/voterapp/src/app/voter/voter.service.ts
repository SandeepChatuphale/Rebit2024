import { Injectable } from '@angular/core';
import { Voter } from '../model/Voter';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class VoterService {
    allVoters : Voter[] = []
    
    readonly BASE_URL = 'http://localhost'
  
    constructor(private http:HttpClient){}

    findAll() : Observable<Voter[]>
    {
      let token = sessionStorage.getItem('token')
      let myheader = new HttpHeaders()
                        .append('Authorization',`Bearer ${token}`)
      return this.http.get<Voter[]>(`${this.BASE_URL}/vs/voter`
                            ,{headers:myheader})
    }

    createVoter(v:Voter){
      let token = sessionStorage.getItem('token')
      let myheader = new HttpHeaders()
                        .append('Authorization',`Bearer ${token}`)
      return this.http.post<Voter>(`${this.BASE_URL}/vs/voter`,v,{headers:myheader})
    }
}
