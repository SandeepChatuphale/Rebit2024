import { Component, DoCheck, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Voter } from '../../model/Voter';
import { FormsModule } from '@angular/forms';

@Component({
  selector: 'app-update',
  imports: [FormsModule],
  templateUrl: './update.component.html',
  styleUrl: './update.component.css'
})
export class UpdateComponent implements OnInit , DoCheck{
  
  @Input()
  voter = new Voter(0,'',0,'','')

  @Output()
  voterEmitter = new EventEmitter<Voter>()

  v = new Voter(0,'',0,'','')

  ngOnInit(): void {}

  ngDoCheck(): void {
    //creating copy 
    this.v.id = this.voter.id
    this.v.name = this.voter.name
    this.v.age = this.voter.age
    this.v.gender = this.voter.gender
    this.v.constituencyName = this.voter.constituencyName
  }

  performUpdate(e:Event)
  {
    e.preventDefault();
    this.voterEmitter.emit(this.v);
  }
}
