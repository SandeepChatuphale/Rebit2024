import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Voter } from '../../model/Voter';
import { VoterService } from '../voter.service';
import { ConstituencyService } from '../../constituency/constituency.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-register',
  imports: [CommonModule,FormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent implements OnInit {

  name:string = ''
  age: number = 0;
  gender : string = ''
  constituencyName = ''

  constituencyNames : string[] = []

  constructor(private service:VoterService,
              private constituencyService:ConstituencyService,
              private r : Router)
  {}

  //life cycle method excuted automatically
  ngOnInit(): void {
    this.constituencyService.findAll().subscribe({
      next : success => {
        let i = 0;
        for (const element of success) 
        {
          this.constituencyNames[i] = element.name;
          i++;
        }
      },
      error: error => {console.log(error)}
    })
  }

  register(e:Event)
  {
    e.preventDefault();
    let v = new Voter(0,this.name,this.age,this.gender,this.constituencyName);
    this.service.createVoter(v).subscribe({
      next: success => {this.r.navigate(['voters'])}
    })
    
  }


}
