import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authGuard: CanActivateFn = (route, state) => {
  console.log('in authGuard')

  let token = sessionStorage.getItem('token')

  let r = inject(Router)

  if(token != null)
    return true;

  else{
    //route to login
    r.navigate(['login'])
    return false;
  }
};
