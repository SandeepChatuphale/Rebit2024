export class TokenResponse{
    constructor(public token:string){}
}