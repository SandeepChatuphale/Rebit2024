export class Voter
{
    constructor(public id:number,
                public name:string,
                public age:number,
                public gender:string,
                public constituencyName:string
    ){
    
    }
}