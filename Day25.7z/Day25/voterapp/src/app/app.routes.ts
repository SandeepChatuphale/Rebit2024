import { Routes } from '@angular/router';
import { LoginComponent } from './user/login/login.component';
import { VotersComponent } from './voter/voters/voters.component';
import { RegisterComponent } from './voter/register/register.component';
import { authGuard } from './guard/auth.guard';
import { NotFoundComponent } from './common/not-found/not-found.component';

export const routes: Routes = [
    {path:'login',component:LoginComponent},
    {path:'voters',component:VotersComponent,canActivate:[authGuard]},
    {path:'voterregitser',component:RegisterComponent},
    {path:'**',component:NotFoundComponent}
];