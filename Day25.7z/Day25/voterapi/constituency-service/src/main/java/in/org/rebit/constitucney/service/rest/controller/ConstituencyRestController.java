package in.org.rebit.constitucney.service.rest.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.org.rebit.constitucney.service.entity.Constituency;

@RestController
@RequestMapping("/constituency")
public class ConstituencyRestController {

	@GetMapping("/{name}")
	public Constituency findByName(@PathVariable String name)
	{
		Constituency c = new Constituency();
		c.setId(1);
		c.setName("Vashi");
		return c;
	}
	
	@GetMapping
	public List<Constituency> findAll(){
		List<Constituency> all = new ArrayList<>();
		Constituency c1 = new Constituency();
		c1.setId(1);
		c1.setName("Vashi");
		
		Constituency c2 = new Constituency();
		c2.setId(2);
		c2.setName("Panvel");
		
		
		Constituency c3 = new Constituency();
		c3.setId(3);
		c3.setName("Nerul");
		
		
		all.add(c1);
		all.add(c2);
		all.add(c3);
		
		return all;
	}
}