package in.org.rebit.evsapp.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.stereotype.Component;

@Component
@Aspect
public class LoggerAspect {
	// @Before("execution(public long countTotalVotersByGender(*))")
	// @After("execution(public long countTotalVotersByGender(*))")
	// @AfterThrowing("execution(public long countTotalVotersByGender(*))")
	// @AfterReturning("execution(public long countTotalVotersByGender(*))")
	// @Before("execution(public *
	// in.org.rebit.evsapp.service.impl.VoterServiceImpl.*(*))")
	@Before("within(in.org.rebit.evsapp.service.impl.VoterServiceImpl)")
	public void logAdvice(JoinPoint jp) {
		System.out.println("logAdvice() is executed for " + jp.getSignature().getName()+"  "
				+ jp.getTarget().getClass() );
	}
}
