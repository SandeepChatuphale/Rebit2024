package in.org.rebit.evsapp.rest.controller;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PostAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.org.rebit.evsapp.entity.EvsUser;
import in.org.rebit.evsapp.jwt.util.JwtUtil;
import in.org.rebit.evsapp.service.EvsUserService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/user")
public class EvsUserRestController {

	@Autowired
	private EvsUserService service;
	
	@Autowired
	private JwtUtil util;

	@Autowired
	private AuthenticationManager manager;

	@PostMapping
	public ResponseEntity<EvsUser> register(@Valid @RequestBody EvsUser user) {
		user = service.createUser(user);
		ResponseEntity<EvsUser> entity = new ResponseEntity<EvsUser>(user, HttpStatus.CREATED);
		return entity;
	}

	@PostMapping("/authentication")
	public ResponseEntity<Map<String, String>> login(@Valid @RequestBody EvsUser user) {
		System.out.println("inside login method of  EvsUserRestController");

		// check if user is valid by invoking authenticate method of
		// AuthenticationManager

		UsernamePasswordAuthenticationToken reqAuth = new UsernamePasswordAuthenticationToken(user.getEmail(),
				user.getPassword());
		try 
		{
			Authentication authenticated = manager.authenticate(reqAuth);//authenticating user with DB
			Collection<? extends GrantedAuthority> authorities = authenticated.getAuthorities();
			
			
			// if yes generate JWT token and send it to client
			String token = util.generateToken(user.getEmail(),authorities);
			
			Map<String, String> m = new HashMap<>();
			m.put("token", token);
			
			//sending key:value so that we can fetch on front-end (Angular)
			ResponseEntity<Map<String, String>> entity = 
								new ResponseEntity<Map<String, String>>(m,HttpStatus.OK);

			return entity;
		}
		catch (Exception e) 
		{
			e.printStackTrace();
	//sending appropriate status code so that we can fetch on front-end (Angular)
			ResponseEntity<Map<String, String>> entity = 
			new ResponseEntity<Map<String, String>>(HttpStatus.UNAUTHORIZED);
			
			return entity;

		}

	}
	

	//this is method is allowed to be accessd by user in ROLE_USER
	
	//post authorize is checked after the target method is executed AND hence it it known as 
	//POST authorize
	@PostAuthorize("#name == authentication.principal")
	@GetMapping("/{name}")
	public EvsUser searchByUsername(@PathVariable String name){
		
		System.out.println("In searchByUsername()");
		EvsUser user = service.findByEmail(name);
		user.setPassword(null);
		return user;
	}
}
