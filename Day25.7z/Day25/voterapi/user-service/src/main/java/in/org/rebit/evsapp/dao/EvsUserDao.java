package in.org.rebit.evsapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.org.rebit.evsapp.entity.EvsUser;

public interface EvsUserDao extends JpaRepository<EvsUser, Integer>{

	@Query("FROM EvsUser u LEFT JOIN FETCH u.roles WHERE u.email = :email")
	EvsUser findByEmail(@Param("email") String email);
}
