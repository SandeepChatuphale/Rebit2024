package in.org.rebit.gateway.service.filter;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.gateway.filter.GatewayFilterChain;
import org.springframework.cloud.gateway.filter.GlobalFilter;
import org.springframework.http.HttpHeaders;
import org.springframework.http.server.reactive.ServerHttpRequest;
import org.springframework.http.server.reactive.ServerHttpRequest.Builder;
import org.springframework.stereotype.Component;
import org.springframework.web.server.ServerWebExchange;

import in.org.rebit.gateway.service.jwt.util.JwtUtil;
import reactor.core.publisher.Mono;

@Component
public class AuthorizationFilter implements GlobalFilter {
	
	@Autowired
	private JwtUtil util;

	@Override
	public Mono<Void> filter(ServerWebExchange exchange, GatewayFilterChain chain) {

		ServerHttpRequest request = exchange.getRequest();
		
		HttpHeaders headers = request.getHeaders();
		List<String> listHeaders = headers.get(HttpHeaders.AUTHORIZATION);
		
		System.out.println("listHeaders============>" + listHeaders);
		if(listHeaders != null) {
		
		String header=listHeaders.get(0);
		
		if(header != null && header.startsWith("Authorization") ) {
			
			String token = this.util.validateToken(header.substring(7));

			System.out.println("===========>" + token);
			
			request = request.mutate().header(HttpHeaders.AUTHORIZATION, token).build();
			
			exchange = exchange.mutate().request(request).build();
		
		}
		}
		
			
		return chain.filter(exchange);
	}

}
