package in.org.rebit.gateway.service.jwt.util;

import java.util.Base64;

import org.springframework.stereotype.Component;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;

@Component
public class JwtUtil {
	
	//@Value("${jwt.token.duration}")
	private int expirationTime = 60 * 60 * 5;
	
	//@Value("${jwt.secret.key}")
	private String secretKey = "secret";

	
	public String validateToken(String token) {
		System.out.println("In side validateToken()");

		String payload = JWT.require(Algorithm.HMAC256(this.secretKey))
							.build()
							.verify(token)
							.getPayload();

		byte[] decodedByteArray = Base64.getDecoder().decode(payload);
		String decodedPayload = new String(decodedByteArray);
		return decodedPayload;
	}
}
