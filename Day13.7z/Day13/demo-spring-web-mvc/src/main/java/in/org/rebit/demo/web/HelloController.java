package in.org.rebit.demo.web;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HelloController {

	@GetMapping("/hi")
	public String sayHello(@RequestParam String name,Model m)
	{
		System.out.println("In sayHello() " + name);
		m.addAttribute("subject", "Java");//this is used to pass data to client
										//using key which is subject
		return "/welcome.jsp";
	}
}
