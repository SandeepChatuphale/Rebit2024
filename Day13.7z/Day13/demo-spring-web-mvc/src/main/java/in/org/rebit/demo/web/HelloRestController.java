package in.org.rebit.demo.web;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloRestController {

				//URI pattern
	@GetMapping("/hello")
	public String sayHello()
	{
		System.out.println("IN sayHello of RestController");
		return "<h1>Hello From Rest Controller</h1>";	//returning data directly
	}
	
	@GetMapping("/hello/{id}")//{id} is a pathvariable 
	public Task getById(@PathVariable("id") int rollNumber)
	{
		Task t = new Task();
		t.setId(rollNumber);
		t.setName("Learn Spring MVC");
		return t;
	}
}




