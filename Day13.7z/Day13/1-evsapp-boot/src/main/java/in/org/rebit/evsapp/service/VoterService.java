package in.org.rebit.evsapp.service;

import in.org.rebit.evsapp.entity.Voter;

public interface VoterService {

	Voter register(Voter v);
	long countTotalVoters();
	long countTotalVotersByGender(String gender);
}
