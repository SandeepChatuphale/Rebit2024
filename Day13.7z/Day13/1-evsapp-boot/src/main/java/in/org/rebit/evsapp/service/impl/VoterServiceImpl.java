package in.org.rebit.evsapp.service.impl;

import org.springframework.stereotype.Service;

import in.org.rebit.evsapp.dao.VoterDao;
import in.org.rebit.evsapp.entity.Voter;
import in.org.rebit.evsapp.service.VoterService;

@Service
public class VoterServiceImpl implements VoterService{

	private VoterDao dao;
	
	
	public VoterServiceImpl(VoterDao dao) {
		this.dao = dao;
	}
	

	@Override
	public Voter register(Voter v) {
		//make a call to DAO
		return this.dao.save(v);
	}

	@Override
	public long countTotalVoters() {
		return this.dao.findCountOfTotalVoters();
	}

	@Override
	public long countTotalVotersByGender(String gender) {
		return this.dao.findCountOfTotalVotersByGender(gender);
	}

}
