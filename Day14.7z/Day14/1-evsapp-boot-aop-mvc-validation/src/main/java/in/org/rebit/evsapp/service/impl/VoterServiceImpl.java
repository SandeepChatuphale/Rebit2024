package in.org.rebit.evsapp.service.impl;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import in.org.rebit.evsapp.dao.VoterDao;
import in.org.rebit.evsapp.entity.Voter;
import in.org.rebit.evsapp.exception.VoterNotFoundException;
import in.org.rebit.evsapp.service.VoterService;

@Service
public class VoterServiceImpl implements VoterService{

	private VoterDao dao;
	
	public VoterServiceImpl(VoterDao dao) {
		this.dao = dao;
	}
	
	@Override
	public Voter register(Voter v) {
		//make a call to DAO
		return this.dao.save(v);
	}

	@Override
	public long countTotalVoters() {
		return this.dao.findCountOfTotalVoters();
	}

	@Override
	public long countTotalVotersByGender(String gender) {
		return this.dao.findCountOfTotalVotersByGender(gender);
	}

	@Override
	public Voter getVoterById(int id) throws VoterNotFoundException {
		
		Optional<Voter> o = this.dao.findById(id);
		
		if(o.isPresent())
			return o.get();
		
		throw new VoterNotFoundException(id);
	}

	@Override
	public List<Voter> getAll() {
		return this.dao.findAll();
	}
	
	@Override
	public void unRegister(int id) {
		this.dao.deleteById(id);	
	}
	
	@Override
	public Voter updateVoter(Voter v) {
		return this.dao.save(v);
	}

}
