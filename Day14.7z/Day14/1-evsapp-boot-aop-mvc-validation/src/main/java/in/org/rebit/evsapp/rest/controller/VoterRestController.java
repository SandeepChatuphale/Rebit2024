package in.org.rebit.evsapp.rest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.org.rebit.evsapp.entity.Voter;
import in.org.rebit.evsapp.exception.VoterNotFoundException;
import in.org.rebit.evsapp.response.exception.representation.VoterNotFoundRepresentation;
import in.org.rebit.evsapp.service.VoterService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/voter") // common portion of URI for all the methods of this class
public class VoterRestController {

	@Autowired
	private VoterService service;

	@GetMapping("/{id}")
	public ResponseEntity<Voter> searchById(@PathVariable int id) throws VoterNotFoundException {
		System.out.println("searchById()");
		Voter foundVoter = this.service.getVoterById(id);
		ResponseEntity<Voter> response = new ResponseEntity<Voter>(foundVoter, HttpStatus.OK);
		return response;
	}

	
	
	@ExceptionHandler(VoterNotFoundException.class)
	public ResponseEntity<VoterNotFoundRepresentation> handleVoterNotFoundException(VoterNotFoundException e) {
		
		VoterNotFoundRepresentation r = new VoterNotFoundRepresentation();
		r.setId(e.getId());
		r.setStatusCode(404);
		r.setMessage(e.getMessage());
		
		ResponseEntity<VoterNotFoundRepresentation> response = new ResponseEntity<>(r, HttpStatus.NOT_FOUND);

		return response;
	}

	
	@GetMapping
	public List<Voter> searchAll() {
		System.out.println("searchAll()");
		return this.service.getAll();
	}

	// mapped to HTTP POST method
	@PostMapping
	public ResponseEntity<Voter> createVoter(@Valid @RequestBody Voter v) {
		System.out.println("create VOter");
		Voter createdVoter = this.service.register(v);
		ResponseEntity<Voter> response = new ResponseEntity<Voter>(createdVoter, HttpStatus.CREATED);
		return response;
	}

	@DeleteMapping("/{id}")
	public ResponseEntity<Void> deleteVoterById(@PathVariable int id) {
		this.service.unRegister(id);

		// ResponseEntity object is used to return appropriate HTTP status code
		ResponseEntity<Void> response = new ResponseEntity<>(HttpStatus.NO_CONTENT);
		return response;

	}

	@PutMapping("/{id}")
	public Voter updateVoter(@PathVariable int id, @RequestBody Voter v) {
		v.setId(id);
		return this.service.updateVoter(v);
	}

}
