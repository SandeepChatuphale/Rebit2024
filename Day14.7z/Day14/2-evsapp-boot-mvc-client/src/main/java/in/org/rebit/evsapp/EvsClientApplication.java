package in.org.rebit.evsapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import in.org.rebit.evsapp.dto.Voter;

@SpringBootApplication
public class EvsClientApplication {

	public static void main(String[] args) {

		SpringApplication.run(EvsClientApplication.class, args);
		
		//class offered by spring acts as client for REST webservice
		//allows us to make REST calls
		RestTemplate rt = new RestTemplate();
		
		int option = 1;
		
		switch(option)
		{
			case 1->{
				int id = 1;
				ResponseEntity<Voter> entity = rt.exchange("http://localhost:8080/voter/1", 
															HttpMethod.GET, null, Voter.class);
				
				System.out.println(entity.getStatusCode());
				System.out.println(entity.getBody());
			}
			
			case 3->
			{
				Voter v = new Voter("amar",12, "Male");
				HttpEntity<Voter> entity = new HttpEntity<Voter>(v);
				ResponseEntity<Voter> response = rt.exchange("http://localhost:8080/voter", 
						HttpMethod.POST, entity, Voter.class);
				
				

			}
		}
		
		
	}
}
