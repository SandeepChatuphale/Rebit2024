package in.org.rebit.sms.exception;

public class StudentNotFoundException extends Exception {

	private int rollNumber;
		
	public StudentNotFoundException(int rollNumber) {
		super("Student Not Found With Roll Number : " + rollNumber);
		this.rollNumber = rollNumber;
	}

	@Override
	public String toString() {
		return "Student Not Found With Roll Number : " + rollNumber;
	}
}