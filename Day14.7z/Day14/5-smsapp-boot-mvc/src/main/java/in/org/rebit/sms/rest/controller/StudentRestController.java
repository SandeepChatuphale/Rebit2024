package in.org.rebit.sms.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.org.rebit.sms.entitiy.Student;
import in.org.rebit.sms.exception.StudentNotFoundException;
import in.org.rebit.sms.service.StudentService;

@RestController
@RequestMapping("/student")
public class StudentRestController {

	@Autowired
	private StudentService service;
	
	@GetMapping("/{id}")
	public Student searchByRollNumber(@PathVariable int id) throws StudentNotFoundException {
		return this.service.getRegisteredStudentByRollNumber(id);
	}
}
