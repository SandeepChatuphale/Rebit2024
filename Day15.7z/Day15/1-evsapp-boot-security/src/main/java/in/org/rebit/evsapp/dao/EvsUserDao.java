package in.org.rebit.evsapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import in.org.rebit.evsapp.entity.EvsUser;

public interface EvsUserDao extends JpaRepository<EvsUser, Integer>{

	EvsUser findByEmail(String email);
}
