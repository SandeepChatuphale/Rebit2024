package in.org.rebit.evsapp.rest.controller.advice;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

//it is to declare global exception handler methods
@RestControllerAdvice
public class GlobalRestControllerAdvice {

	
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public ResponseEntity<String> handleMethoArgumentNotValidException(MethodArgumentNotValidException e)
	{
		
		System.out.println("IN handleMethoArgumentNotValidException");
		ResponseEntity<String> entity = 
				new ResponseEntity<String>(e.getMessage(), HttpStatus.BAD_REQUEST);
		return entity;
	}
}
