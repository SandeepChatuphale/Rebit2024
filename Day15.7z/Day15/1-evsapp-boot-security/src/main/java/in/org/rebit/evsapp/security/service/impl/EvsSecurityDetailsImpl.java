package in.org.rebit.evsapp.security.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import in.org.rebit.evsapp.dao.EvsUserDao;
import in.org.rebit.evsapp.entity.EvsUser;

@Service
public class EvsSecurityDetailsImpl implements UserDetailsService {

	@Autowired
	private EvsUserDao dao;
	
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		System.out.println("In loadUserByUsername " + username);
		
		//TODO - fetch details from DB
		EvsUser evsUser = dao.findByEmail(username);
		
		User authenticatedUser = new User(evsUser.getEmail(),
										  evsUser.getPassword(),
										AuthorityUtils.createAuthorityList("ROLE_USER","ROLE_ADMIN"));
		
		
		
		
		return authenticatedUser;
	}

}
