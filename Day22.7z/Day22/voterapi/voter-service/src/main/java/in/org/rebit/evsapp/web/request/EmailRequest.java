package in.org.rebit.evsapp.web.request;

public class EmailRequest {

	private String toReceiver;
	private String subject;
	
	public String getToReceiver() {
		return toReceiver;
	}
	public void setToReceiver(String toReceiver) {
		this.toReceiver = toReceiver;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	
	
}
