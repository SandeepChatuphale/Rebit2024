package in.org.rebit.evsapp.jwt.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.boot.json.JsonParser;
import org.springframework.boot.json.JsonParserFactory;
import org.springframework.http.HttpHeaders;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.www.BasicAuthenticationFilter;

import in.org.rebit.evsapp.jwt.util.JwtUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

//responsible for accepting jwt token from client which is passed via headers
//responsible for checking validatity of JWT token
public class JwtFilter extends BasicAuthenticationFilter {

	private static final String BEARER = "Bearer";
	
	public JwtFilter(AuthenticationManager authenticationManager) {
		super(authenticationManager);
	}

	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {

		// responsible for accepting jwt token from client which is passed via headers
		String authorizationHeader = request.getHeader(HttpHeaders.AUTHORIZATION);

		System.out.println("in JwtFilter before checking header");
		
		if (authorizationHeader != null && authorizationHeader.startsWith(BEARER)) {

			System.out.println("inside JwtFilter");
			String jwtToken = authorizationHeader.substring(7);
			System.out.println(jwtToken);

			
			//responsible for checking validity of JWT token
			JwtUtil util = new JwtUtil();
			
			//if token is validated
			String data = util.validateToken(jwtToken);
			
			
			//fetch claims from token
			
			//fetch username
			JsonParser jsonParser = JsonParserFactory.getJsonParser();
			Map<String, Object> map = jsonParser.parseMap(data);
			String username = (String)map.get("USER_NAME");
						
	
			//fetch roles
			List<String> roles = (List<String>)map.get("ROLES");
			
			List<GrantedAuthority> authorities = new ArrayList<>();
			for (String role : roles) {
				System.out.println(role);
				authorities.add(new SimpleGrantedAuthority(role));
			}
			
				
			UsernamePasswordAuthenticationToken auth = new UsernamePasswordAuthenticationToken(username, 
																							  null,
																							  authorities);
			//store this information at place which spring security can access
			//when needed
			SecurityContextHolder.getContext().setAuthentication(auth);
			
			
		}	
		
		chain.doFilter(request, response);	//pass on request to next filter in chain
		
		
		
		
	}

}
