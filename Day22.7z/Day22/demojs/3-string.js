let str = "Hello";

let age = 22

console.log('age of amit is ' + age)//old style of concatenation

//ES-6
console.log(`age of amit is ${age}`);//template strings

