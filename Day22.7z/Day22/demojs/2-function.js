function sayHello()
{
    console.log('sayHello()')
}

sayHello(); //call

function accept(i)
{
    console.log(i)
}
accept(10)
accept('hi')
accept();

function get()
{
    return 'result'
}