var i = 10;
console.log(i)
i = 20;
console.log(i)
i = 'Hi';   //bcz js is dynamically typed language
console.log(i)

//ES6
let age = 12;
age = 'abc';

//ES6
const pi = 3.14;


let voter = {
                "id":1,
                "name":"amit",
                "age":12,
                "gender":"male"
            }

console.log(voter)
