package in.org.rebit.constitucney.service.rest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.org.rebit.constitucney.service.entity.Constituency;

@RestController
@RequestMapping("/constituency")
public class ConstituencyRestController {

	@GetMapping("/{name}")
	public Constituency findByName(@PathVariable String name)
	{
		Constituency c = new Constituency();
		c.setId(1);
		c.setName("Vashi");
		return c;
	}
}
