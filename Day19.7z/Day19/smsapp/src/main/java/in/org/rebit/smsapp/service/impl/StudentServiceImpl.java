package in.org.rebit.smsapp.service.impl;

import in.org.rebit.smsapp.dao.StudentDao;
import in.org.rebit.smsapp.entity.Student;
import in.org.rebit.smsapp.service.StudentService;

public class StudentServiceImpl implements StudentService{

	
	private StudentDao dao;
	
	
	public StudentServiceImpl(StudentDao dao) {
		super();
		this.dao = dao;
		System.out.println("djsldjsld");
	}

	
	
	public StudentDao getDao() {
		return dao;
	}



	public void setDao(StudentDao dao) {
		System.out.println("okoko");
		this.dao = dao;
	}



	@Override
	public Student searchById(int id) {
		System.out.println("in searchbyId");
		return this.dao.findById(id);
	}

}
