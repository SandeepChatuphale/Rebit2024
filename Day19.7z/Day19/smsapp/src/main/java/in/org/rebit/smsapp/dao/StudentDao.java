package in.org.rebit.smsapp.dao;

import in.org.rebit.smsapp.entity.Student;

public interface StudentDao {

	Student findById(int id);
}
