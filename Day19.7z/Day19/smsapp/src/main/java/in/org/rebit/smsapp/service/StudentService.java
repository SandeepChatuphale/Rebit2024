package in.org.rebit.smsapp.service;

import in.org.rebit.smsapp.entity.Student;

public interface StudentService {

	Student searchById(int id);
}
