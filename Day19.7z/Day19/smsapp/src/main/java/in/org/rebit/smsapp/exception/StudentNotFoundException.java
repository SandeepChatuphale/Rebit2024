package in.org.rebit.smsapp.exception;

public class StudentNotFoundException extends Exception{

}
