package in.org.rebit.smsapp.entity;

public class Student {

}
