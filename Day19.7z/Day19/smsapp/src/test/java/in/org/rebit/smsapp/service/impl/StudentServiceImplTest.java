package in.org.rebit.smsapp.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import in.org.rebit.smsapp.dao.StudentDao;
import in.org.rebit.smsapp.entity.Student;
import in.org.rebit.smsapp.exception.StudentNotFoundException;

public class StudentServiceImplTest {

	@InjectMocks
	private StudentServiceImpl service;
	
	@Mock	//inject mock object
	private StudentDao dao;
	
	@BeforeEach
	public void setUp() {
		//this.dao = Mockito.mock(StudentDao.class); 	//creating Mock of StudentDao
		MockitoAnnotations.openMocks(this);				//enable Mock annotations
		
		//service = new StudentServiceImpl(dao);		//injecting mocked dao to service
	}
	
	@Test
	public void searchByIdTest()
	{
		//arrange
		int id = 1;
		Student s = new Student();
		
		when(dao.findById(id)).thenReturn(s);
		
		//act
		Student actual = this.service.searchById(id);
		
		//assert
		assertNotNull(actual);
		assertEquals(s, actual);
	}
	
	@Disabled
	@Test
	public void searchByIdShouldThrowStudentNotFoundExceptionTest()
	{
		int id = 1;
		
		when(dao.findById(id)).thenThrow(StudentNotFoundException.class);
		
		assertThrows(StudentNotFoundException.class,() -> this.service.searchById(id));
	
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
