package in.org.rebit.mathapp;

public class MathOperation {

	public int add(int num1,int num2)
	{
		return num1 + num2;
	}
	
	public int divide(int num1,int num2)
	{
		return num1 / num2;
	}
	
	public double squareRoot(double num) {
		return 0;
	}
	
}
