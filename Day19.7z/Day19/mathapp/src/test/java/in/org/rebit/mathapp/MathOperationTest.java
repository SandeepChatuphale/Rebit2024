package in.org.rebit.mathapp;

import static org.junit.jupiter.api.Assertions.assertThrows;

import java.util.concurrent.TimeUnit;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Timeout;

@DisplayName("Math related tests")
public class MathOperationTest {

	private MathOperation m;
	
	@BeforeAll
	public static void init() {}
	
	
	@BeforeEach
	public void setUp() {
		m = new MathOperation();
	}
	
	@AfterEach
	public void tearDown()
	{
		
	}
	

	@Timeout(value = 10,unit = TimeUnit.SECONDS)
	@DisplayName("Add test")
	@Test	//this annotation denotes that this is a test method 
	public void addTest()
	{
		//arrange		given
		MathOperation m = new MathOperation();
		int num1 = 10;
		int num2 = 10;
		int expected = 20;
		
		//act		when		
		int actual =  m.add(num1, num2);

		//assert		then
		Assertions.assertTrue(expected == actual);
	}
	
	@Test	//this annotation denotes that this is a test method 
	public void divideTest()
	{
		//arrange		given
		MathOperation m = new MathOperation();
		int num1 = 10;
		int num2 = 10;
		int expected = 1;
		
		//act		when		
		int actual =  m.divide(num1, num2);

		//assert		then
		Assertions.assertTrue(expected == actual);
	}
	
	@Test	//this annotation denotes that this is a test method 
	public void divideShouldThrowArithmaticExceptionTest()
	{
		//arrange		given
		MathOperation m = new MathOperation();
		int num1 = 10;
		int num2 = 0;
		//int expected = 1;

		assertThrows(ArithmeticException.class, ()->m.divide(num1, num2));
	}
	
	@Test
	@Disabled	//denotes that this test case is disabled
	public void squareRootTest()
	{
		
	}

}
