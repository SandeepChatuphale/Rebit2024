package in.org.rebit.emai.service.entity;

public class Email {

	private int id;
	private String toReceiver;
	private String subject;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getToReceiver() {
		return toReceiver;
	}
	public void setToReceiver(String toReceiver) {
		this.toReceiver = toReceiver;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	@Override
	public String toString() {
		return "Email [id=" + id + ", toReceiver=" + toReceiver + ", subject=" + subject + "]";
	}
	
	
}
