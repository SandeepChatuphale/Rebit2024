package in.org.rebit.evsapp.rest.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.org.rebit.evsapp.entity.Constituency;

@RestController
@RequestMapping("/constituency") // common portion of URI for all the methods of this class
public class ConstituencyRestController {

	@GetMapping("/{id}")
	public Constituency findById(@PathVariable int id)
	{
		Constituency c  = new Constituency();
		c.setId(1);
		c.setName("Vashi");
		return c;
	}
}
