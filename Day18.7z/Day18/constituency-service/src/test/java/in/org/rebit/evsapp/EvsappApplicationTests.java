package in.org.rebit.evsapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvsappApplicationTests {

	@Test
	void contextLoads() {
	}

}
