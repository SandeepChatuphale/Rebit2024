package in.org.rebit.evsapp.feign.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import in.org.rebit.evsapp.web.request.EmailRequest;
import in.org.rebit.evsapp.web.response.EmailResponse;

//@FeignClient(url = "http://localhost:8081",name="es")
@FeignClient(name="es")
public interface VoterFeignClient {

	@PostMapping("/email")
	EmailResponse processEmail(@RequestBody EmailRequest r);
}
