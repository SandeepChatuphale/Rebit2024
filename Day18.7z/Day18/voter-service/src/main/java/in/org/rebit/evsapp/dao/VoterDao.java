package in.org.rebit.evsapp.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import in.org.rebit.evsapp.entity.Voter;

public interface VoterDao extends JpaRepository<Voter, Integer>{

	
	@Query("SELECT COUNT(*) FROM Voter")
	long findCountOfTotalVoters();
	
	@Query("SELECT COUNT(*) FROM Voter v WHERE v.gender = :g")
	long findCountOfTotalVotersByGender(@Param("g") String gender);
}
