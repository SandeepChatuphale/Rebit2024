package in.org.rebit.emai.web.response;

public class EmailResponse {

	private boolean status;

	public boolean isStatus() {
		return status;
	}

	public void setStatus(boolean status) {
		this.status = status;
	}
	
}
