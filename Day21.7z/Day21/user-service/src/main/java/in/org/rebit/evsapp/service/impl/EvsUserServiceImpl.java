package in.org.rebit.evsapp.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import in.org.rebit.evsapp.dao.EvsUserDao;
import in.org.rebit.evsapp.entity.EvsUser;
import in.org.rebit.evsapp.service.EvsUserService;

@Service
public class EvsUserServiceImpl implements EvsUserService {

	@Autowired
	private EvsUserDao dao;
	
	@Autowired
	private PasswordEncoder encoder;
	
	@Override
	public EvsUser createUser(EvsUser user) {
		
		String encodedPassword = encoder.encode(user.getPassword());
		user.setPassword(encodedPassword);
		
		EvsUser registeredUser = dao.save(user);
		registeredUser.setPassword(null);//setting password to null before sending 
										//user object back to client
		
		return registeredUser;
	}

	@Override
	public EvsUser findById(int id) {
		return this.dao.findById(id).get();
	}

	@Override
	public EvsUser findByEmail(String username) {
		// TODO Auto-generated method stub
		return this.dao.findByEmail(username);
	}

}
