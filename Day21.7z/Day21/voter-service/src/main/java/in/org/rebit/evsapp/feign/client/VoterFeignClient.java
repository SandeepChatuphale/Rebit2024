package in.org.rebit.evsapp.feign.client;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;

import in.org.rebit.evsapp.web.request.EmailRequest;
import in.org.rebit.evsapp.web.response.ConstituencyResponse;
import in.org.rebit.evsapp.web.response.EmailResponse;

//@FeignClient(url = "http://localhost:8081",name="es")
@FeignClient(name="gs")
public interface VoterFeignClient {

	@PostMapping("/es/email")
	EmailResponse processEmail(@RequestBody EmailRequest r,@RequestHeader String heder);
	
	@GetMapping("/cs/constituency/{name}")
	public ConstituencyResponse findConstituencyByName(@PathVariable String name,@RequestHeader String heder);
	
}
