package in.org.rebit.evsapp.exception;

public class VoterNotFoundException extends Exception {

	private int id;
	
	public VoterNotFoundException(int id) {
		super("Voter with id " + id  + " NOT FOUND");
		this.id = id;
	}
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	@Override
	public String toString() {
		return "Voter with id " + id  + " NOT FOUND";
	}
}
