package in.org.rebit.evsapp.configuration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class EvsAppSecurityConfiguration {

	@Autowired
	private UserDetailsService service;
	
	
	@Bean
	SecurityFilterChain defaultSecurity(HttpSecurity http) throws Exception
	{
		
		//any request MUST be authenticated
		//http.authorizeHttpRequests(request -> request.anyRequest().authenticated());
	
		//disabled for REST webservice BUT MUST be enabled for web application
		http.csrf(c -> c.disable() );
		
		http
			.authorizeHttpRequests(
						request -> request.requestMatchers(HttpMethod.GET,"/voter/**").hasAnyRole("USER")
										.requestMatchers(HttpMethod.POST, "/user").permitAll()
										  .anyRequest().authenticated()								
								  );
		
			
		//Instructing spring security to use EvsSecurityDetailsImpl class to load user from DB
		http.userDetailsService(service);	
		
		//REST should be state less
		http.sessionManagement(s -> 
				s.sessionCreationPolicy(SessionCreationPolicy.STATELESS));
		
		
		http.httpBasic(Customizer.withDefaults());	//enabling basic authentication
		
		
		return http.build();
	}
	
	@Bean
	PasswordEncoder getEncoder()
	{
		BCryptPasswordEncoder encoder = new BCryptPasswordEncoder();
		System.out.println(encoder.encode("rebit"));
		return encoder;
	}
	
	
}
