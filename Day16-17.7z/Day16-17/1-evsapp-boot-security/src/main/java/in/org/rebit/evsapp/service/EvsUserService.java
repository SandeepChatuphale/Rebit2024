package in.org.rebit.evsapp.service;

import in.org.rebit.evsapp.entity.EvsUser;

public interface EvsUserService {

	EvsUser createUser(EvsUser user);
}
