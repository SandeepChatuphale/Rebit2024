package in.org.rebit.evsapp.rest.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import in.org.rebit.evsapp.entity.EvsUser;
import in.org.rebit.evsapp.service.EvsUserService;
import jakarta.validation.Valid;

@RestController
@RequestMapping("/user")
public class EvsUserRestController {

	@Autowired
	private EvsUserService service;
	
		
	
	@PostMapping
	public ResponseEntity<EvsUser> register(@Valid @RequestBody EvsUser user)
	{
		UsernamePasswordAuthenticationFilter u;
		user = service.createUser(user);
		ResponseEntity<EvsUser> entity = 
					new ResponseEntity<EvsUser>(user, HttpStatus.CREATED);
		return entity;
	}
	
	
}
