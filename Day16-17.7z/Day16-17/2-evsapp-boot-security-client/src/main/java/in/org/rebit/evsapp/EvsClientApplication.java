package in.org.rebit.evsapp;

import java.util.Base64;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import in.org.rebit.evsapp.dto.Voter;

@SpringBootApplication
public class EvsClientApplication {

	public static void main(String[] args) {

		SpringApplication.run(EvsClientApplication.class, args);
		
		//class offered by spring acts as client for REST webservice
		//allows us to make REST calls
		RestTemplate rt = new RestTemplate();
		
		int option = 1;
		
		switch(option)
		{
			case 1->{
				int id = 1;
				
				//to invoke secured endpoints we MUST pass user name password
				//for basic authentication 
				//1) create a string with username:passoword
				String credentails = "rebit:rebit";
				
				//2) encode credentials with Base64
				String encodedCredentials =  Base64.getEncoder()
											.encodeToString(credentails.getBytes());
				
				//3) create a string with - Basic encodedCredentials
				String basic = "Basic " + encodedCredentials;
				
				//4)pass this string via Authorization header
				HttpHeaders headers = new HttpHeaders();
				headers.add("Authorization", basic);
				
				
				HttpEntity<String> reqEntity = new HttpEntity<>(headers);
				
				
				
	ResponseEntity<Voter> entity = rt.exchange("http://localhost:8080/voter/1", 
															HttpMethod.GET, 
															reqEntity, 
															Voter.class);
				
				
				
				System.out.println(entity.getStatusCode());
				System.out.println(entity.getBody());
			}
			
			case 3->
			{
				//to invoke secured endpoints we MUST pass user name password
				//for basic authentication 
				//1) create a string with username:passoword
				String credentails = "rebit:rebit";
				
				//2) encode credentials with Base64
				String encodedCredentials =  Base64.getEncoder()
											.encodeToString(credentails.getBytes());
				
				//3) create a string with - Basic encodedCredentials
				String basic = "Basic " + encodedCredentials;
				
				//4)pass this string via Authorization header
				HttpHeaders headers = new HttpHeaders();
				headers.add("Authorization", basic);
				
				
				Voter v = new Voter("amar",12, "Male");
				
				HttpEntity<Voter> entity = new HttpEntity<Voter>(v,headers);
				
				ResponseEntity<Voter> response = rt.exchange("http://localhost:8080/voter", 
						HttpMethod.POST, entity, Voter.class);
				
				

			}
		}
		
		
	}
}
