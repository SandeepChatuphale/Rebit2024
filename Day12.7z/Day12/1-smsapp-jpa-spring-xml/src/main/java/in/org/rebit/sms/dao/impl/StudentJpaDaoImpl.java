package in.org.rebit.sms.dao.impl;

import java.util.List;
import java.util.Optional;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import in.org.rebit.sms.dao.StudentDao;
import in.org.rebit.sms.entitiy.Student;

public class StudentJpaDaoImpl implements StudentDao {

	private EntityManagerFactory factory;
	
	private String fullStudentJpql;
	
	public StudentJpaDaoImpl() {
		this.factory = Persistence.createEntityManagerFactory("myPersistenceUnit");
	}
	
	public StudentJpaDaoImpl(EntityManagerFactory factory) {

		this.factory = factory; 
	}
	
	public void setFullStudentJpql(String fullStudentJpql) {
		this.fullStudentJpql = fullStudentJpql;
	}

	@Override
	public Optional<Student> createStudent(Student student) {

		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(student);
		tx.commit();
		em.close();
		
		return Optional.of(student);
	}

	@Override
	public Optional<Student> getStudentByRollNumber(int rollNumber) {

		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Student foundStudent = em.find(Student.class, rollNumber);
		System.out.println(foundStudent.getAttempts());
		
		tx.commit();
		em.close();

		return Optional.of(foundStudent);
	}
	

	@Override
	public Optional<Student> deleteStudentByRollNumber(int rollNumber) {
		
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Student foundStudent = em.find(Student.class, rollNumber);
		em.remove(foundStudent);
		
		tx.commit();
		em.close();
		
		return Optional.of(foundStudent);
	}


	@Override
	public Optional<Student> getFullStudentByRollNumber(int rollNumber) {
		
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		TypedQuery<Student> query = em.createQuery(fullStudentJpql, Student.class);
		query.setParameter("r", rollNumber);
		Student foundStudent = query.getSingleResult();
	
		tx.commit();
		em.close();
	
		return Optional.of(foundStudent);
		
		//Student foundStudent = em.find(Student.class, rollNumber);
		
		//fetching subjects separately
//		Set<String> subjects = foundStudent.getSubjects();
//		for (String subject : subjects) {
//			//assigning subjects  to student
//			foundStudent.assignNewSubject(subject);	
//		}
	}

	@Override
	public List<Student> getAllStudents() {
		
		//Student is-a Entity class (NOT TABLE)
		String jpql = "SELECT DISTINCT s FROM Student s LEFT JOIN FETCH s.subjects";
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		TypedQuery<Student> query = em.createQuery(jpql, Student.class);
		List<Student> students = query.getResultList();
		
//		for (Student student : students) {
//			
//			Set<String> subjects = student.getSubjects();
//			
//			for (String sub : subjects) {
//				student.assignNewSubject(sub);
//			}
//		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
//		@Override
//		public List<Student> getAllStudents() {
//			
//			//Student is-a Entity class (NOT TABLE)
//			String jpql = "select distinct s FROM Student as s INNER JOIN FETCH s.subjects  WHERE s.rollNumber = :a";
//			EntityManager em = factory.createEntityManager();
//			EntityTransaction tx = em.getTransaction();
//			tx.begin();
//			TypedQuery<Student> query = em.createQuery(jpql, Student.class);
//			query.setParameter("a", 1);
//			List<Student> students = query.getResultList();
//			System.out.println(students.size());
//			
////			for (Student student : students) {
////				
////				Set<String> subjects = student.getSubjects();
////				
////				for (String sub : subjects) {
////					student.assignNewSubject(sub);
////				}
////			}

			
//			@Override
//			public List<Student> getAllStudents() {
//				
//				//Student is-a Entity class (NOT TABLE)
//				String jpql = "select distinct s FROM Student as s INNER JOIN FETCH s.subjects  WHERE s.rollNumber = :a";
//				EntityManager em = factory.createEntityManager();
//				EntityTransaction tx = em.getTransaction();
//				tx.begin();
//				TypedQuery<Student> query = em.createQuery(jpql, Student.class);
//				query.setParameter("a", 1);
//				List<Student> students = query.getResultList();
//				System.out.println(students.size());
//				
////				for (Student student : students) {
////					
////					Set<String> subjects = student.getSubjects();
////					
////					for (String sub : subjects) {
////						student.assignNewSubject(sub);
////					}
////				}

		tx.commit();
		return students;
	}

	@Override
	public Optional<Student> updateStudentByRollNumber(int rollNumber, Student student) {

		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		student.setRollNumber(rollNumber);
		student = em.merge(student);
		tx.commit();
		em.close();
		
		return Optional.of(student);
	}
	
	public void cleanUp()
	{
		System.out.println("in cleanUP()");
		factory.close();
	}
}