package in.org.rebit.evsapp;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import in.org.rebit.evsapp.configuration.ApplicationConfiguration;
import in.org.rebit.evsapp.entity.Voter;
import in.org.rebit.evsapp.service.VoterService;

public class EvsApplication {

	public static void main(String[] args) {
		
		
		AnnotationConfigApplicationContext container = null;
		
		//creating spring container by reading xml configuration file
		container = new AnnotationConfigApplicationContext(ApplicationConfiguration.class);
				
		//asking for bean from container of type - VoterService
		VoterService service = container.getBean(VoterService.class);
		
		
		
		int option = 3;
		
		switch (option) {
		
		//register use case
		case 1:
		{
			
			Voter v = new Voter("prachi", 21, "Female");
			service.register(v);
			break;			
		}
		
		//find count of total voters use case
		case 2:
		{
			System.out.println(service.countTotalVoters());
			break;
		}
		
		//find count of total voters use case
		case 3:
		{
			System.out.println(service.countTotalVotersByGender("Female"));
			break;
		}
		default:
		}	
	}
}
