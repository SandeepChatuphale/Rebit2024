package in.org.rebit.evsapp.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import jakarta.persistence.EntityManagerFactory;

@Configuration
@EnableJpaRepositories("in.org.rebit.evsapp.dao") 						//enabling data jpa support

@EnableTransactionManagement()										//to enable transaction support

@ComponentScan("in.org.rebit.evsapp")									//instructing spring to search all classes
																	//annotated with @Component in this package and its sub-packages
public class ApplicationConfiguration {
	
	@Bean(destroyMethod = "destroy",name = "entityManagerFactory")	//entityManagerFactory MUST be this id searched by spring-data-jpa
	public LocalEntityManagerFactoryBean getEntityManagerFactory() 
	{
		LocalEntityManagerFactoryBean factory = new LocalEntityManagerFactoryBean();
		factory.setPersistenceUnitName("evsPersistentUnit");
		return factory;
	}
	
	//this bean is responsible for managing tx automatically
	@Bean(name = "transactionManager")								//transactionManager MUST be this id searched by spring-data-jpa
	public PlatformTransactionManager getTransactionManager(EntityManagerFactory factory)
	{
		JpaTransactionManager tx = new JpaTransactionManager(factory);
		return tx;
	}
}