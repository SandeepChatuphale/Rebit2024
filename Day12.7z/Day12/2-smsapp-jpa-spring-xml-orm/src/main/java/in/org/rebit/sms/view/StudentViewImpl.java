package in.org.rebit.sms.view;

import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

import in.org.rebit.sms.entitiy.Student;

public class StudentViewImpl implements StudentView {

	@Override
	public void showHeader() {
		printMessage("Welome to SchoolManagement App");

	}

	@Override
	public void showFooter() {
		printMessage("@2024; Rebit");
	}

	@Override
	public void printMessage(String message) {
		System.out.println(message);

	}

	@Override
	public void printMessage(String message, int type) {
		if (type == 1)
			printMessage(message);
		else
			System.err.println(message);
	}

	@Override
	public void showMenu() {
		// Text Block Feature For MultiLine String ( Java 15 )
		String menu = """
				\n---------------------------------------------------
				Enter Your Choice !!
				1. Register New Student
				2. Show All Students Details
				3. Show Specific Student Details By Roll Number
				4. Update Specific Student By Roll Number
				5. DeRegister Specific Student By Roll Number
				6. Students ABOVE 80
				7. Show Specific Student Full Details By Roll Number
				!! Enter -1 To Exit Application !!
				""";

		printMessage(menu);
	}

	@Override
	public void printStudentDetails(Student student) {

		System.out.println(student);
	}

	@Override
	public double acceptDouble(Scanner sc) {
		return sc.nextDouble();
	}

	@Override
	public void printStudentDetails(List<Student> students,Predicate<Student> p) {
		students.forEach(student -> {
			if (p.test(student)) {
				System.out.println(student);
			}
		});
//		for (Student student : students) {
//			if (p.test(student)) {
//				System.out.println(student);
//			}
//		}
	}
	
	@Override
	public void printStudentDetails(List<Student> students) {	
		
		students.forEach(System.out::println);
		//students.forEach(student -> System.out.println(student));

		//		for (Student student : students) {
//			printStudentDetails(student);
//		}
	}
}
