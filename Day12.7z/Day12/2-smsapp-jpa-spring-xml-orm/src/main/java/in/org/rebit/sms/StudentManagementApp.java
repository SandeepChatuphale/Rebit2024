package in.org.rebit.sms;

import java.util.Collections;
import java.util.List;
import java.util.Scanner;

import org.springframework.context.support.ClassPathXmlApplicationContext;

import in.org.rebit.sms.entitiy.Student;
import in.org.rebit.sms.exception.StudentNotFoundException;
import in.org.rebit.sms.service.StudentService;
import in.org.rebit.sms.view.StudentView;

public class StudentManagementApp {

	public static void main(String[] args)  {

		try (Scanner sc = new Scanner(System.in);
			ClassPathXmlApplicationContext container = new ClassPathXmlApplicationContext("applicationContext.xml");) 
		{
			
			StudentService studentService = container.getBean(StudentService.class);
			StudentView view = container.getBean(StudentView.class);

			view.printMessage("!! Welcome To Rebit Student Management System !!");
			int choice = 0;
			do {
				view.showMenu();
				choice = sc.nextInt();
				// Switch Expression Feature Added in JDK 14
				switch (choice) {
				case 1 ->
				{
					view.printMessage("Enter Name : ");
					String name = sc.next();
					view.printMessage("Enter Percentage : ");
					double percentage = view.acceptDouble(sc);
					view.printMessage("Enter Attempts : ");
					int attempts = sc.nextInt();
			
						Student student = new Student(name, percentage, attempts);
						
						//assign subjects to student (hard-coded values)
						student.assignNewSubject("Java");
						student.assignNewSubject("Spring");
						
						Student registeredStudent = studentService.registerStudent(student);
						if (registeredStudent == null) {
							view.printMessage("Student Not Created !!", 0);
						} else {
							view.printMessage("Student Successfully Created !!");
							view.printStudentDetails(registeredStudent);
						}
					

					break;
				}

				case 2 -> {
					List<Student> allStudents = studentService.getAllRegisteredStudents();
					if (allStudents.isEmpty()) {
						view.printMessage("No Student Records Found !! Try Again Later !!",0);
					} else {
						view.printMessage("All Registered Students Details Below : ");
						view.printStudentDetails(allStudents);
					}
					break;
				}
				case 3 -> {
					view.printMessage("Search Student Detail By Roll Number !!");
					view.printMessage("Enter Roll Number : ");
					int rollNumber = sc.nextInt();
					Student student;
					try {
						student = studentService.getRegisteredStudentByRollNumber(rollNumber);
						view.printStudentDetails(student);
					} catch (StudentNotFoundException e) {
						view.printMessage(e.toString(),0);
						// e.printStackTrace(); // For Developers
					}
					break;
				}
				case 4 -> {
					view.printMessage("Updating Specific Student Detail !!");
					view.printMessage("Enter Roll Number To Update : ");
					int rollNumberToUpdate = sc.nextInt();
					view.printMessage("Enter New Number Of Attempts : ");
					int newAttempt = sc.nextInt();
					Student studentToBeUpdated;
					try {
						studentToBeUpdated = studentService.getRegisteredStudentByRollNumber(rollNumberToUpdate);
						studentToBeUpdated.setAttempts(newAttempt);
						Student updatedStudent = studentService.updateStudentByRollNumber(rollNumberToUpdate,
								studentToBeUpdated);
						view.printStudentDetails(updatedStudent);
					} catch (StudentNotFoundException e) {
						view.printMessage(e.toString(), 0);
						// e.printStackTrace(); // For Developers
					}
					break;
				}
				case 5 -> {
					view.printMessage("DeRegistering Specific Student By Roll Number !!");
					view.printMessage("Enter Roll Number To DeRegister : ");
					int rollNumberToDeRegister = sc.nextInt();
					Student student = studentService.unregisterStudent(rollNumberToDeRegister);
					if (student == null) {
						view.printMessage("Student Not Found !!", 0);
					} else {
						view.printMessage("Student DeRegistered Successfully !!");
						view.printStudentDetails(student);
					}
					break;
				}
				
				case 6->{
					view.printMessage("Students with above 80 score");
					List<Student> students = studentService.getAllRegisteredStudents();
					//view.printStudent(students, student -> student.getPercentage()>80);
					//view.printStudentDetails(students, student -> student.getName().startsWith("M"));
					//view.printStudentDetails(students, student -> 
					//										student.getAttempts()<3 
					//										&& 
					//										student.getPercentage()>80);
					
Collections.sort(students,(s1,s2) -> (int)(s2.getPercentage() - s1.getPercentage()));
		view.printStudentDetails(students);
		
				}
				
				case 7 ->{
						
					view.printMessage("Search Student Detail By Roll Number !!");
					view.printMessage("Enter Roll Number : ");
					int rollNumber = sc.nextInt();
					Student student;
					try {
						student = studentService.getRegisteredFullStudentByRollNumber(rollNumber);
						view.printStudentDetails(student);
					} catch (StudentNotFoundException e) {
						view.printMessage(e.toString(),0);
						// e.printStackTrace(); // For Developers
					}

				}
				case -1 -> {
					//container.close();//closing container so that all resources can be closed
					view.printMessage("Thanks , Visit Again !!");
					break;
				}
				default -> view.printMessage("Wrong Input , Please Enter Correct Option !!");
				}

			} while (choice != -1);

		}
	}
}
