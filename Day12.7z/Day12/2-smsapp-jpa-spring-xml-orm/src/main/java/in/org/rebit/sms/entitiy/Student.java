package in.org.rebit.sms.entitiy;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CollectionTable;
import javax.persistence.Column;
import javax.persistence.ElementCollection;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "tbl_student")
public class Student implements Comparable<Student> {
	// instance variables
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)	//for generating roll number automatically
	@Column(name = "rNo")
	private int rollNumber;
	@Column(nullable = false)
	private String name;
	private double percentage;
	private int attempts;
	@ElementCollection(fetch = FetchType.LAZY)
	@CollectionTable(name = "tbl_subjects",joinColumns = @JoinColumn(name="rNo_FK"))
	private Set<String> subjects;
	
	
	public Student() {
		// TODO Auto-generated constructor stub
	}
	
	// Parameterized Constructors
	public Student(String name, double percentage, int attempts) {
		super();
		this.name = name;
		this.percentage = percentage;
		this.attempts = attempts;
		this.subjects = new HashSet<>();
	}

	public int getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	public int getAttempts() {
		return attempts;
	}

	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}
	
	public void assignNewSubject(String subject)
	{
		this.subjects.add(subject);
	}
	
	//returning read-only collection for view purpose ONLY
	public Set<String> getSubjects()
	{
		return Collections.unmodifiableSet(this.subjects);
	}
	
	@Override
	public int compareTo(Student o) {
		return (int) (o.percentage - this.percentage);
	}

	@Override
	public String toString() {
		return "Student [rollNumber=" + rollNumber + ", name=" + name + ", percentage=" + percentage + ", attempts="
				+ attempts + ", subjects=" + subjects + "]";
	}
	
}
