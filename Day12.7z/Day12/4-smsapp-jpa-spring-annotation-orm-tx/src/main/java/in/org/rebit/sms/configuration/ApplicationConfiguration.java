package in.org.rebit.sms.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import jakarta.persistence.EntityManagerFactory;

@Configuration
@EnableTransactionManagement	//to enable transaction support
@PropertySource("classpath:application.properties")
@ComponentScan("in.org.rebit.sms")//instructing spring to search all classes
		//annotated with @Component in this package and its sub-packages
public class ApplicationConfiguration {
	
	@Bean(destroyMethod = "destroy")
	public LocalEntityManagerFactoryBean getEntityManagerFactory() 
	{
		LocalEntityManagerFactoryBean factory = new LocalEntityManagerFactoryBean();
		factory.setPersistenceUnitName("myPersistenceUnit");
		
		return factory;
	}
	
	//this bean is responsible for managing tx automatically
	@Bean
	public PlatformTransactionManager getTransactionManager(EntityManagerFactory factory)
	{
		JpaTransactionManager tx = new JpaTransactionManager(factory);
		return tx;
	}
}