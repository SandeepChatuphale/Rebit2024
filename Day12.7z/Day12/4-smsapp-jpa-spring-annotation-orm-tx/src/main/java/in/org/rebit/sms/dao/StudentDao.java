package in.org.rebit.sms.dao;

import java.util.List;
import java.util.Optional;

import in.org.rebit.sms.entitiy.Student;

public interface StudentDao {

	Optional<Student> createStudent(Student student);

	Optional<Student>  getStudentByRollNumber(int rollNumber);
	
	Optional<Student>  getFullStudentByRollNumber(int rollNumber);

	List<Student> getAllStudents();

	Optional<Student> updateStudentByRollNumber(int rollNumber, Student student);

	Optional<Student> deleteStudentByRollNumber(int rollNumber);

}