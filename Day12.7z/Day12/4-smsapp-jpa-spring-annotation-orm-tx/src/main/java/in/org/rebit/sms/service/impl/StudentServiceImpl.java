package in.org.rebit.sms.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Stream;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import in.org.rebit.sms.dao.StudentDao;
import in.org.rebit.sms.entitiy.Student;
import in.org.rebit.sms.exception.StudentNotFoundException;
import in.org.rebit.sms.service.StudentService;

@Service
//@Component
//This class handles business methods,business exceptions and transactions
public class StudentServiceImpl implements StudentService {

	@Autowired
	// "Code To Interface" Approach
	private StudentDao studentDao;

//	@Autowired
//	// constructor
//	public StudentServiceImpl(StudentDao studentDao) {
//		this.studentDao = studentDao;
//	}
//	
//	@Autowired
//	public void setStudentDao(StudentDao dao)
//	{
//		System.out.println("In setter of StudentServiceImpl");
//		this.studentDao = dao;
//	}

	@Override
	public Student registerStudent(Student s) {

		Optional<Student> o = studentDao.createStudent(s);
		
		if(o.isPresent())
			return o.get();
		return null;
	}

	@Override
	public List<Student> getAllRegisteredStudents() {
		return studentDao.getAllStudents();
	}

	@Override
	public Student getRegisteredStudentByRollNumber(int rollNumber) throws StudentNotFoundException {

		Optional<Student> o = studentDao.getStudentByRollNumber(rollNumber);
		
		if(o.isPresent())
		{
			Student foundStudent = o.get();
			return foundStudent;
		}
		
		throw new StudentNotFoundException(rollNumber);
	}

	@Override
	public List<Student> getStudentsSortedByPercentage() {
		ArrayList<Student> sortedStudents = new ArrayList<>(studentDao.getAllStudents());
		Collections.sort(sortedStudents);
		return sortedStudents;
	}

	@Override
	public List<Student> getStudentsSortedByAttempts() {
		ArrayList<Student> sortedStudents = new ArrayList<>(studentDao.getAllStudents());
		Comparator<Student> comparator = new Comparator<Student>() {
			@Override
			public int compare(Student o1, Student o2) {
				return o1.getAttempts() - o2.getAttempts();
			}
		};

		Collections.sort(sortedStudents, comparator);
		return sortedStudents;
	}

	@Override
	public Student unregisterStudent(int rollNumber) {
		
		Optional<Student> o = studentDao.deleteStudentByRollNumber(rollNumber);
		
		if(o.isPresent())
			return o.get();
		
		return null;

	}

	@Override
	public Student updateStudentByRollNumber(int rollNumber, Student student) {
		Optional<Student> o = studentDao.updateStudentByRollNumber(rollNumber, student);
		if(o.isPresent())
			return o.get();
		return null;
	}
	
	private Stream<Student> getStudentStream(Predicate<Student> p)
	{
		return this.getAllRegisteredStudents()
		   .stream()
		   .filter(p);
	}
	
	@Override
	public List<Student> getAllStudentsNameStartsWith(String startsWith) {
		return this.getStudentStream(student -> student.getName().startsWith(startsWith))
				   .toList();
	}

	@Override
	public List<Student> getAllStudentsScoredMoreThan(double score) {

		return this.getStudentStream(student -> student.getPercentage() > score)
				   .toList();		
	}
	

	@Override
	public long findTotalStudensSocredMoreThan(double score) {
		return this.getStudentStream(student -> student.getPercentage() > score)
				   .count();
	}


	@Override
	public List<String> findNamesOfAllStudentsScoredMoreThan(double score) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> findAllStudentsLearningSubject(String subject) {
		return null;	   
	}

	@Override
	public Student getRegisteredFullStudentByRollNumber(int rollNumber) throws StudentNotFoundException {
		Optional<Student> o = this.studentDao.getFullStudentByRollNumber(rollNumber);
		if(o.isPresent())
			return o.get();
		return null;
	}



}
