package in.org.rebit.sms;

import org.springframework.orm.jpa.support.OpenEntityManagerInViewFilter;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import in.org.rebit.sms.configuration.ApplicationConfiguration;
import jakarta.servlet.Filter;
import jakarta.servlet.FilterRegistration;
import jakarta.servlet.FilterRegistration.Dynamic;
import jakarta.servlet.ServletContext;

public class StudentManagementWebApp extends AbstractAnnotationConfigDispatcherServletInitializer{

	@Override
	protected Class<?>[] getRootConfigClasses() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	protected Class<?>[] getServletConfigClasses() {
		// TODO Auto-generated method stub
		return new Class[] {ApplicationConfiguration.class};
	}

	@Override
	protected String[] getServletMappings() {
		// TODO Auto-generated method stub
		return new String[] {"/"};
	}
	
	@Override
	protected Dynamic registerServletFilter(ServletContext servletContext, Filter f) {

		OpenEntityManagerInViewFilter entityManagerInViewFilter = new OpenEntityManagerInViewFilter();
	    entityManagerInViewFilter.setEntityManagerFactoryBeanName("entityManagerFactory");
	    entityManagerInViewFilter.setPersistenceUnitName("myPersistenceUnit");
	    FilterRegistration.Dynamic filter = servletContext.addFilter("openEntityManagerInViewFilter", entityManagerInViewFilter);
	    filter.addMappingForUrlPatterns(null, false, "/");

	    return filter;
	}

}
