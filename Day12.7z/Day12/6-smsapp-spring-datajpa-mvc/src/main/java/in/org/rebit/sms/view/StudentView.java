package in.org.rebit.sms.view;

import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

import in.org.rebit.sms.entitiy.Student;

public interface StudentView {

	void showHeader();

	void showFooter();

	void printMessage(String message);

	void printMessage(String message, int type);

	void showMenu();
	
	double acceptDouble(Scanner sc);

	void printStudentDetails(Student student);

	void printStudentDetails(List<Student> students);

	void printStudentDetails(List<Student> students, Predicate<Student> p);
	

	

}