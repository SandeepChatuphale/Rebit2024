package in.org.rebit.sms.configuration;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.LocalEntityManagerFactoryBean;
import org.springframework.orm.jpa.support.OpenEntityManagerInViewFilter;
import org.springframework.orm.jpa.support.OpenEntityManagerInViewInterceptor;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import jakarta.persistence.EntityManagerFactory;

@Configuration
@EnableJpaRepositories(basePackages = "in.org.rebit.sms.dao") 						//enabling data jpa support

@EnableTransactionManagement()										//to enable transaction support

@PropertySource("classpath:application.properties")					//loading and reading mentioned properties file

@ComponentScan("in.org.rebit.sms")									//instructing spring to search all classes
																	//annotated with @Component in this package and its sub-packages

@EnableWebMvc
public class ApplicationConfiguration {
	
	@Bean(destroyMethod = "destroy",name = "entityManagerFactory")	//entityManagerFactory MUST be this id searched by spring-data-jpa
	public LocalEntityManagerFactoryBean getEntityManagerFactory() 
	{
		
		LocalEntityManagerFactoryBean factory = new LocalEntityManagerFactoryBean();
		factory.setPersistenceUnitName("myPersistenceUnit");
		return factory;
	}
	
	//this bean is responsible for managing tx automatically
	@Bean(name = "transactionManager")								//transactionManager MUST be this id searched by spring-data-jpa
	public PlatformTransactionManager getTransactionManager(EntityManagerFactory factory)
	{
		JpaTransactionManager tx = new JpaTransactionManager(factory);
		return tx;
	}
	
	
//	@Bean
//	public OpenEntityManagerInViewFilter getEntityManagerInViewIntercepto()
//	{
//		OpenEntityManagerInViewFilter interceptor = new OpenEntityManagerInViewFilter();
//		return interceptor;
//	}
//	
	
	
	
	
//	@Bean
//	public OpenEntityManagerInViewInterceptor getEntityManagerInViewInterceptor()
//	{
//		OpenEntityManagerInViewInterceptor interceptor = new OpenEntityManagerInViewInterceptor();
//		return interceptor;
//	}
}