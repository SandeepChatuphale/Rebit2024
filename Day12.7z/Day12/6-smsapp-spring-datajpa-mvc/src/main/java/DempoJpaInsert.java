import in.org.rebit.sms.entitiy.Student;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class DempoJpaInsert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		Student s = new Student("abc", 1, 1);
		//s.setRollNumber(1);
		em.persist(s);
		tx.commit();
		em.clear();
		factory.close();

	}

}
