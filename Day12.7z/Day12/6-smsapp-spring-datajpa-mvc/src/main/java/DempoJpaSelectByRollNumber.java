import in.org.rebit.sms.entitiy.Student;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.Persistence;

public class DempoJpaSelectByRollNumber {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("myPersistenceUnit");
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		
		Student foundStudent = em.find(Student.class, 1);
		System.out.println(foundStudent.getAttempts());
		tx.commit();
		em.close();
		factory.close();
		
	}
}
