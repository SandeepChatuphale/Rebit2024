package in.org.rebit.evsapp.dao;

import in.org.rebit.evsapp.entity.Voter;

public interface VoterDao {

	Voter save(Voter v);
	
	long findCountOfTotalVoters();
	
	long findCountOfTotalVotersByGender(String gender);
}
