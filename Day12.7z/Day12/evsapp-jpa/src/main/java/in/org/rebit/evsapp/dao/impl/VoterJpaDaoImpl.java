package in.org.rebit.evsapp.dao.impl;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.TypedQuery;

import in.org.rebit.evsapp.dao.VoterDao;
import in.org.rebit.evsapp.entity.Voter;

public class VoterJpaDaoImpl implements VoterDao {

	private EntityManagerFactory factory;
	
	public VoterJpaDaoImpl() {
		factory = Persistence.createEntityManagerFactory("evsPersistentUnit");
	}
	
	@Override
	public Voter save(Voter v) {
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		em.persist(v);
		tx.commit();
		em.close();
				
		return v;
	}

	@Override
	public long findCountOfTotalVoters() {
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();

		String jpql = "SELECT COUNT(*) FROM Voter";
		TypedQuery<Long> query = em.createQuery(jpql, Long.class);
		Long count = query.getSingleResult();
		
		tx.commit();
		em.close();
		
		return count;
	}

	@Override
	public long findCountOfTotalVotersByGender(String gender) {
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();

		String jpql = "SELECT COUNT(*) FROM Voter v WHERE v.gender = :g";
		TypedQuery<Long> query = em.createQuery(jpql, Long.class);
		query.setParameter("g", gender);
		Long count = query.getSingleResult();
		
		tx.commit();
		em.close();
		
		return count;

	}

}
