package in.org.rebit.evsapp;

import in.org.rebit.evsapp.dao.VoterDao;
import in.org.rebit.evsapp.dao.impl.VoterJpaDaoImpl;
import in.org.rebit.evsapp.entity.Voter;
import in.org.rebit.evsapp.service.VoterService;
import in.org.rebit.evsapp.service.impl.VoterServiceImpl;

public class EvsApplication {

	public static void main(String[] args) {
		
		VoterDao dao = new VoterJpaDaoImpl();
		VoterService service = new VoterServiceImpl(dao);
		
		int option = 3;
		
		switch (option) {
		
		//register use case
		case 1:
		{
			
			Voter v = new Voter("prachi", 21, "Female");
			service.register(v);
			break;			
		}
		
		//find count of total voters use case
		case 2:
		{
			System.out.println(service.countTotalVoters());
			break;
		}
		
		//find count of total voters use case
		case 3:
		{
			System.out.println(service.countTotalVotersByGender("Female"));
			break;
		}
		default:
		}	
	}
}
