import java.util.HashMap;
import java.util.Map;

public class DemoHashMap {

	public static void main(String[] args) {

		Map<String, Integer> m = new HashMap<>();
		m.put("Mumbai", 22);
		m.put("Pune",20);
		System.out.println(m);
		System.out.println(m.size());
		System.out.println(m.isEmpty());
		System.out.println(m.get("Mumbai"));
		m.put("Mumbai", 33);//duplicate key is NOT allowed
		System.out.println(m);
		m.put("Delhi", 20);//duplicate value is allowed
		System.out.println(m);
		
		
	}

}
