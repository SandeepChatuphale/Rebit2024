package demojava8;

public class MyClass implements I1,I2{

	
	
	public void process() {
		I1.super.process();//invoking process() of I1 interface
	}

	@Override
	public void print() {
		
	}

}
