package demojava8;

public interface I1 {

	void print();
	
	default void process() {
		System.out.println("In process() of I1");
	}
}
