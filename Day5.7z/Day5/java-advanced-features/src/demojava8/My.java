package demojava8;

import java.util.List;

interface Printable {
	void print();
	
	//default method added in java8
	public default void printFormat() {
		System.out.println("IN default printFormat()");
	}
	
	//added in java8
	static void of() {
		System.out.println("In of() method - static");
	}
	
	
	//added in java 9
	private void helper() {}
}
 public class My implements Printable{

	@Override
	public void print() {
	}
	@Override
	public void printFormat() {
		System.out.println("IN class's printFormat()");
	}
	
	public static void main(String[] args) {
		Printable m = new My();
		m.printFormat();
		Printable.of();
		
		
		List<String> cities = List.of("Mumbai","Chennai");
		
		
		
		
		
		
		
	}
}
