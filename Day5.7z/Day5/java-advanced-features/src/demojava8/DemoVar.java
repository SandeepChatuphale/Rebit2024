package demojava8;

import java.util.*;
public class DemoVar {

	public static void main(String []argss) {
		
		var i = 10;//added in java 10
		//i = ""; ERROR
		var name = "";
		
		
		var l = new ArrayList<String>();
		
	}
}
