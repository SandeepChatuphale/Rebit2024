package demojava8;

public interface I2 {

	//void print();
	
	default void process() {
		System.out.println("In process() of I2");
	}
	
	default void print() {}
}
