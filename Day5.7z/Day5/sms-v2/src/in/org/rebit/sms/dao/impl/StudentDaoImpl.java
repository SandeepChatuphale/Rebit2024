package in.org.rebit.sms.dao.impl;

import java.util.ArrayList;
import java.util.List;

import in.org.rebit.sms.dao.StudentDao;
import in.org.rebit.sms.entitiy.Student;

public class StudentDaoImpl implements StudentDao {
	private List<Student> students;

	public StudentDaoImpl() {
		this.students = new ArrayList<Student>();
	}

	@Override
	public Student createStudent(Student student) {
		students.add(student);
		return student;
	}

	@Override
	public Student getStudentByRollNumber(int rollNumber) {
		Student foundStudent = null;
		for (Student student : students) {
			if (student.getRollNumber() == rollNumber)
				foundStudent = student;
		}
		return foundStudent;
	}

	@Override
	public List<Student> getAllStudents() {
		return students;
	}

	
	@Override
	public Student updateStudentByRollNumber(int rollNumber, Student student) {
		for (Student s : students) {
			if (s.getRollNumber() == rollNumber) {
				s.setAttempts(student.getAttempts());
				return s;
			}
		}
		return null;
	}

	@Override
	public Student deleteStudentByRollNumber(int rollNumber) {
		Student foundStudent = null;
		for (Student student : students) {
			if (student.getRollNumber() == rollNumber) {
				foundStudent = student;
				break;
			}
		}
		if (foundStudent != null) {
			students.remove(foundStudent);
		}
		return foundStudent;
	}
}
