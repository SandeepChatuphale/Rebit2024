package in.org.rebit.sms.dao;

import java.util.List;

import in.org.rebit.sms.entitiy.Student;

public interface StudentDao {

	Student createStudent(Student student);

	Student  getStudentByRollNumber(int rollNumber);

	List<Student> getAllStudents();

	Student updateStudentByRollNumber(int rollNumber, Student student);

	Student deleteStudentByRollNumber(int rollNumber);

}