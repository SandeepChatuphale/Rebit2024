package in.org.rebit.sms.entitiy;

public class Student implements Comparable<Student> {
	// instance variables
	private int rollNumber;
	private String name;
	private double percentage;
	private int attempts;
	
	
	// static variable
	private static int count;

	
	// Parameterized Constructors
	public Student(String name, double percentage, int attempts) {
		super();
		count++;
		this.rollNumber = count;
		this.name = name;
		this.percentage = percentage;
		this.attempts = attempts;
	}

	public int getRollNumber() {
		return rollNumber;
	}

	public void setRollNumber(int rollNumber) {
		this.rollNumber = rollNumber;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPercentage() {
		return percentage;
	}

	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}

	public int getAttempts() {
		return attempts;
	}

	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}

	@Override
	public String toString() {
		return "Student [rollNumber=" + rollNumber + ", name=" + name + ", percentage=" + percentage + ", attempts="
				+ attempts + "]";
	}

	@Override
	public int compareTo(Student o) {
		return (int) (o.percentage - this.percentage);
	}
}
