package in.org.rebit.sms.service;

import java.util.List;

import in.org.rebit.sms.entitiy.Student;
import in.org.rebit.sms.exception.StudentNotFoundException;

public interface StudentService {

	Student registerStudent(Student s);

	List<Student> getAllRegisteredStudents();

	Student getRegisteredStudentByRollNumber(int rollNumber) throws StudentNotFoundException;

	Student unregisterStudent(int rollNumber);

	
	Student updateStudentByRollNumber(int rollNumber, Student student);

	List<Student> getStudentsSortedByPercentage();

	List<Student> getStudentsSortedByAttempts();

	
}