package in.org.rebit.sms.factory;

import in.org.rebit.sms.dao.StudentDao;
import in.org.rebit.sms.dao.impl.StudentDaoImpl;
import in.org.rebit.sms.service.StudentService;
import in.org.rebit.sms.service.impl.StudentServiceImpl;
import in.org.rebit.sms.view.StudentView;
import in.org.rebit.sms.view.StudentViewImpl;

public class BeanFactory {
	public StudentDao getStudentDao() {
		StudentDao studentDao = new StudentDaoImpl();
		return studentDao;
	}

	public StudentService getStudentService() {
		StudentService studentService = new StudentServiceImpl(getStudentDao());
		return studentService;
	}
	
	public StudentView getStudentViewImpl()
	{
		return new StudentViewImpl();
	}
}
