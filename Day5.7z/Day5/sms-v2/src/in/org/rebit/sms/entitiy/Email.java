package in.org.rebit.sms.entitiy;

public class Email {

	private int id;
	private String to;
	private String subject;
		
	public Email(int id, String to, String subject) {
		this.id = id;
		this.to = to;
		this.subject = subject;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getTo() {
		return to;
	}
	public void setTo(String to) {
		this.to = to;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
}
