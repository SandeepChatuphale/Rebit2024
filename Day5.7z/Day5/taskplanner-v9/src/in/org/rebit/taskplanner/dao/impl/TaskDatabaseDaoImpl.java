package in.org.rebit.taskplanner.dao.impl;

import java.util.List;

import in.org.rebit.taskplanner.dao.TaskDao;
import in.org.rebit.taskplanner.entity.Task;

public class TaskDatabaseDaoImpl implements TaskDao {

	@Override
	public Task save(Task taskTobeCreated) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Task findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Task update(Task taskToBeUpdated) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean deleteById(int id) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<Task> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	

}
