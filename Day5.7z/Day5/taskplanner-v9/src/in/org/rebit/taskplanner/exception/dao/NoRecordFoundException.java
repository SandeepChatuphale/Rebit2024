package in.org.rebit.taskplanner.exception.dao;

public class NoRecordFoundException extends Exception {

}
