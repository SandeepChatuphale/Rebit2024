import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import in.org.rebit.taskplanner.entity.Task;
import in.org.rebit.taskplanner.util.TaskComparasionByName;

public class DeomComparator {

	public static void main(String[] args) {
		Task t1 = new Task(false, "Java");
		Task t2 = new Task(true, "React");
		Task t3 = new Task(false, "Angular");
		List<Task> tasks = new ArrayList<>();
		tasks.add(t2);
		tasks.add(t3);
		tasks.add(t1);
		
		System.out.println("Before sorting");
		System.out.println(tasks);
		
		System.out.println();
		System.out.println("After sorting by id (using comparable)");
		Collections.sort(tasks);
		System.out.println(tasks);
		
		
		System.out.println();
		System.out.println("After sorting by name (using comparator)");
		Collections.sort(tasks,new TaskComparasionByName());
		System.out.println(tasks);
		
		
		
		
		
	}
}
