package in.org.rebit.sms.entity;

public class Student {

	private static int count;
	
	private int rollNumber;
	private String name;
	private int attempts;
	private double percentage;
	
	public Student(String name, int attempts, double percentage) {
		super();
		this.rollNumber = ++count;
		this.name = name;
		this.attempts = attempts;
		this.percentage = percentage;
	}
	public int getRollNumber() {
		return rollNumber;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAttempts() {
		return attempts;
	}
	public void setAttempts(int attempts) {
		this.attempts = attempts;
	}
	public double getPercentage() {
		return percentage;
	}
	public void setPercentage(double percentage) {
		this.percentage = percentage;
	}
}
