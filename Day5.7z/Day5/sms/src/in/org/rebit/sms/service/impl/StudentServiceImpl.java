package in.org.rebit.sms.service.impl;

import in.org.rebit.sms.dao.StudentDao;
import in.org.rebit.sms.dao.impl.StudentDaoImpl;
import in.org.rebit.sms.entity.Student;
import in.org.rebit.sms.service.StudentService;

public class StudentServiceImpl implements StudentService{

	private StudentDao dao;
	
	public StudentServiceImpl() {
		this.dao = new StudentDaoImpl();
	}
	
	@Override
	public Student registerStdudent(Student studentToBeRegisterd) {
		return this.dao.save(studentToBeRegisterd);
	}

}
