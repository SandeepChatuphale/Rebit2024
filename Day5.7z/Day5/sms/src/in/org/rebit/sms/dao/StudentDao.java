package in.org.rebit.sms.dao;

import in.org.rebit.sms.entity.Student;

public interface StudentDao {

	Student save(Student studentToBeCreated);
}
