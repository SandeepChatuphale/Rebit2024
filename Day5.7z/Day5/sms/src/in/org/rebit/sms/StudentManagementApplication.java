package in.org.rebit.sms;

import in.org.rebit.sms.entity.Student;
import in.org.rebit.sms.service.StudentService;
import in.org.rebit.sms.service.impl.StudentServiceImpl;

public class StudentManagementApplication {

	public static void main(String[] args) {
		
		StudentService service =new StudentServiceImpl();
		Student s = new Student("Amit", 2, 80);
		service.registerStdudent(s);
		
	}

}
