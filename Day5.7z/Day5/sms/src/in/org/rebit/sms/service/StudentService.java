package in.org.rebit.sms.service;

import in.org.rebit.sms.entity.Student;

public interface StudentService {

	Student registerStdudent(Student s);
}
