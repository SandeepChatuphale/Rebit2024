package in.org.rebit.sms.dao.impl;

import in.org.rebit.sms.dao.StudentDao;
import in.org.rebit.sms.entity.Student;

public class StudentDaoImpl implements StudentDao{

	@Override
	public Student save(Student studentToBeCreated) {
		return studentToBeCreated;
	}

}
