import { CommonModule } from '@angular/common';
import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { Voter } from '../../model/Voter';
import { VoterService } from '../voter.service';

@Component({
  selector: 'app-register',
  imports: [CommonModule,FormsModule],
  templateUrl: './register.component.html',
  styleUrl: './register.component.css'
})
export class RegisterComponent {

  name:string = ''
  age: number = 0;
  gender : string = ''

  constituencyNames : string[] = []

  constructor(private service:VoterService)
  {
    this.constituencyNames.push('vashi');
    this.constituencyNames.push('Nerul')
  }

  register(e:Event)
  {
    e.preventDefault();
    let v = new Voter(10,this.name,this.age,this.gender);
    this.service.createVoter(v)
  }


}
