import { Component } from '@angular/core';
import { Voter } from '../../model/Voter';
import { CommonModule } from '@angular/common';
import { VoterService } from '../voter.service';

@Component({
  selector: 'app-voters',
  imports: [CommonModule],//CommonModule needed for ngFor
  templateUrl: './voters.component.html',
  styleUrl: './voters.component.css'
})
export class VotersComponent {

  allVoters : Voter[] = []

  //DI - injecting object of VoterService
  constructor(private service:VoterService){
    this.allVoters = service.findAll()
  }

  deleteById(id:number)
  { 
  }
}
