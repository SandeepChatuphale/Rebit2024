import { Injectable } from '@angular/core';
import { Voter } from '../model/Voter';

@Injectable({
  providedIn: 'root'
})
export class VoterService {

    allVoters : Voter[] = []
  
    constructor(){
    
      //TODO - fetch these values from backend
      let v1 = new Voter(1,'amit',34,'male')
      let v2 = new Voter(2,'jaya',64,'female')
  
      this.allVoters.push(v1)
      this.allVoters.push(v2)
    }

    findAll()
    {
      return this.allVoters
    }

    createVoter(v:Voter){
      this.allVoters.push(v)
    }
}
