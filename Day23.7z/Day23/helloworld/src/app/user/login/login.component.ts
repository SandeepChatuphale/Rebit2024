import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { User } from '../../model/User';
import { UserService } from '../user.service';

@Component({
  selector: 'app-login',
  imports: [FormsModule],
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  //these are used to hold values passed by user
  email : string = ''
  password : string = ''

  //used to decide disabled status of submit btn
  btnStatus = true

  //it is used show error message
  message : string = ''

  constructor(private service:UserService){}

  //this method is responsible for checking username and password
  //should be executed when user clicks submit button of login component
  performLogin(e:Event)
  {
    e.preventDefault();//preventing default form submission event
    let u = new User(this.email,this.password);
    

    //ONLY after call to subscribe() call is made to REST service
    this.service.authenticate(u).subscribe(
      {
      //callback function executes automatically when response is received from server
       next: success => this.message = 'Login Success',
       error: error => {
        if(error.status == 403)
          this.message = 'Forbidden'
        if(error.status == 401)
          this.message = 'invalid credentials'
       }
      }
    )

    /*
    if(this.service.authenticate(u))//invoking method of service class
      this.message = 'Login Success';
    else
      
    */
  }


  changeBtnStatus()
  {
    if(this.email.length < 3)
    {
      this.btnStatus = true
    }
    else{
      this.btnStatus = false
    }
  }
}
