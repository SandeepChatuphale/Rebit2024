import { Injectable } from '@angular/core';
import { User } from '../model/User';
import { HttpClient } from '@angular/common/http';
import { TokenResponse } from '../model/TokenResponse';

@Injectable({
  providedIn: 'root'
})
export class UserService {

  readonly BASE_URL = 'http://localhost'

  constructor(private http:HttpClient) { }

  authenticate(u:User)
  {
    //make a REST call
    const URL = this.BASE_URL + "/us/user/authentication"

    return this.http.post<TokenResponse>(URL,u)

    /*
    if(u.email == 'rebit' && u.password == 'rebit')
      return true;
    else
      return false;
    */
  }
}
