package in.org.rebit.evsapp.dao;

import static org.junit.jupiter.api.Assertions.assertNotNull;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase.Replace;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.boot.test.autoconfigure.orm.jpa.TestEntityManager;

import in.org.rebit.evsapp.entity.Voter;

//@DataJpaTest
//@AutoConfigureTestDatabase(replace = Replace.NONE)
public class VoterDaoImplTest_disabled {

	@Autowired
	private VoterDao dao;
	
	@Autowired
	private TestEntityManager em;
	
	@Test
	public void saveTest()
	{
		Voter v = new Voter("amit", 34, "Male");
		
		Voter registerdVoter =  dao.save(v);
		
		assertNotNull(registerdVoter);
	
	}
	
	public void fetchAllVotersTest()
	{
		
	}
	
}
