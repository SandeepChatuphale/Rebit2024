package in.org.rebit.evsapp.rest.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;

import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.Optional;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;

import in.org.rebit.evsapp.dao.VoterDao;
import in.org.rebit.evsapp.entity.Voter;
import in.org.rebit.evsapp.service.VoterService;
import in.org.rebit.evsapp.service.impl.VoterServiceImpl;

@SpringBootTest
@AutoConfigureMockMvc
public class VoterRestControllerTest {

	//capable of making http calls
	@Autowired
	private MockMvc mockMvc;
	
	//@Mock
	@MockitoBean //mock and register with spring container
	//@MockBean - deprecated
	private VoterServiceImpl service;
	
	@MockitoBean
	private VoterDao dao;
	
	public VoterRestControllerTest() {
		MockitoAnnotations.openMocks(this);
	}
	
	
	
	@Disabled
	@Test
	public void getTest() throws Exception
	{

		mockMvc.perform(get("/voter/greeting"))
				.andExpect(status().isOk())				//asserting status code
				.andExpect(content().string("Hello"))	//asserting body of response
				.andExpect(content().contentType("text/plain;charset=UTF-8"))	//asserting contenttype
				.andDo(print());//printing on console for debugging
	}
	
	@Test
	public void searchByIdTest() throws Exception
	{
		int existingId = 1;
		
		Voter v = new Voter("Sachin", 34, "Male");
		
		when(dao.findById(existingId)).thenReturn(Optional.of(v));
		
		when(service.register(v)).thenReturn(v);
		
		mockMvc.perform(get("/voter/{id}",existingId))
				.andExpect(status().isOk());
	}
	
	
	@Disabled
	@Test
	public void createVoterTest() throws Exception
	{
		//arrange
		Voter v = new Voter("Sachin", 34, "Male");
		
		ObjectMapper mapper = new ObjectMapper();
		
		//converting java object to JSON string using jackson
		String content = mapper.writeValueAsString(v);
		
		System.out.println(content);
		
	
		when(service.register(v)).thenReturn(v);
//	
		System.out.println(service.getClass());
		System.out.println(service.register(v));
		System.out.println(service);
	
		
		mockMvc.perform(
						post("/voter")
						.accept(MediaType.APPLICATION_JSON)
						.contentType(MediaType.APPLICATION_JSON)
						.content(content)
					   )
						.andExpect(status().isCreated())
						.andExpect(jsonPath("name").value("Sachin"));
		
		
		
	}
	
	
	
	
	
	
		
}
