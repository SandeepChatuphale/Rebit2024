package in.org.rebit.evsapp.service.impl;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.when;

import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import in.org.rebit.evsapp.dao.VoterDao;
import in.org.rebit.evsapp.entity.Voter;
import in.org.rebit.evsapp.exception.EmailNotSentException;
import in.org.rebit.evsapp.exception.VoterNotFoundException;
import in.org.rebit.evsapp.service.EmailService;

public class VoterServiceImplTest_disabled {

	@Mock
	private VoterDao dao;
	
	@Mock
	private EmailService email;
	
	@InjectMocks	//which ever mock objects needed for service inject them
	private VoterServiceImpl service;
	
	@BeforeEach
	public void setUp() {
		MockitoAnnotations.openMocks(this);
	}
	
	@Test
	public void registerTest() throws EmailNotSentException
	{
		//arrage
		Voter v = new Voter("Amit", 34, "Male");
		
		when(dao.save(v)).thenReturn(v);
		when(email.sendEmail()).thenReturn(true);
		//act
		Voter registeredVoter = service.register(v);
		
		//assert
		assertNotNull(registeredVoter);
		assertEquals(registeredVoter, v);
	}
	
	@Test
	public void registerShouldResigerVoterButThrowEmailNotSentExceptionTest() throws EmailNotSentException
	{
		//arrage
		Voter v = new Voter("Amit", 34, "Male");
		
		when(dao.save(v)).thenReturn(v);
		when(email.sendEmail()).thenReturn(false);
		//act
		
		assertThrows(EmailNotSentException.class,()-> service.register(v));
	}
	
	@Test
	public void getVoterByIdShouldReturnVoterTest() throws VoterNotFoundException
	{
		//arrange
		int id = 1;
		Voter existingVoter = new Voter("Amir", 23, "Male");
		
		when(dao.findById(id)).thenReturn(Optional.of(existingVoter));
		
		//act
		Voter foundVoter = service.getVoterById(id);
		
		//assert
		assertNotNull(foundVoter);
		assertEquals(existingVoter, foundVoter);
		
		
		
		
	}
	
	
	@Test
	public void getVoterByIdShouldThrowVoterNotFoundExceptionTest() throws VoterNotFoundException
	{
		//arrange
		int nonExsitingId = 1;

	
		when(dao.findById(nonExsitingId)).thenReturn(Optional.empty());

		//act , assert
		assertThrows(VoterNotFoundException.class, ()->service.getVoterById(nonExsitingId));
		
		
		
		
		
	}
	
	
	
	
	
	
	
	
}
