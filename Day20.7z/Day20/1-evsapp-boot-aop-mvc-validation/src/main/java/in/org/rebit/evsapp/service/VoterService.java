package in.org.rebit.evsapp.service;

import java.util.List;

import in.org.rebit.evsapp.entity.Voter;
import in.org.rebit.evsapp.exception.EmailNotSentException;
import in.org.rebit.evsapp.exception.VoterNotFoundException;

public interface VoterService {

	Voter register(Voter v) throws EmailNotSentException;
	Voter getVoterById(int id) throws VoterNotFoundException;
	List<Voter> getAll();
	long countTotalVoters();
	long countTotalVotersByGender(String gender);
	
	Voter updateVoter(Voter v);
	void unRegister(int id);
}
