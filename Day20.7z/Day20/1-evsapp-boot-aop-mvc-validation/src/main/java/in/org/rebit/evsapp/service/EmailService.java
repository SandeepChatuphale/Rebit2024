package in.org.rebit.evsapp.service;

public interface EmailService {

	boolean sendEmail();
}
