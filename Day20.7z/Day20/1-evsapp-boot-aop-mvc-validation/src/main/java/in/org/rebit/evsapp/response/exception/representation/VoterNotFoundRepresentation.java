package in.org.rebit.evsapp.response.exception.representation;

//this class is used to represent exception information in JSON form
public class VoterNotFoundRepresentation {

	private int id;
	private int statusCode;
	private String message;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getStatusCode() {
		return statusCode;
	}
	public void setStatusCode(int statusCode) {
		this.statusCode = statusCode;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
}
