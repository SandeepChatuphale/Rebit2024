package in.org.rebit.evsapp.service.impl;

import org.springframework.stereotype.Service;

import in.org.rebit.evsapp.service.EmailService;

@Service
public class EmailServiceImpl implements EmailService{

	@Override
	public boolean sendEmail() {
		return true;
	}

}
