package in.org.rebit.evsapp.exception;

public class EmailNotSentException extends Exception {

}
