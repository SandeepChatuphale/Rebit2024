import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

public class Demo {

	Demo(){
		System.out.println("IN no arg constructor");
	}
	
	Demo(int i){
		System.out.println("in parameterized constructor " + i);
	}
	
	public static void main(String[] args) {

//		Predicate<String> p = str -> str.length() > 5;
//		System.out.println( p.test("Mumbai") );
//		
//		Supplier<String> s = () -> "Hello From supplier";
//		System.out.println(s.get());

			
		Supplier<Demo> s1 = Demo::new;
		Demo d1 = s1.get();//object will be created of Demo using no-arg constructor bcz 
						//call to constructor reference
		
		Function<Integer, Demo> f = Demo::new;
		System.out.println(f.apply(10));	//make a call to parameterized consgtructor
		
	
//		Consumer<String> c = i -> System.out.println(i);
//		c.accept("Consumer");
//		
//		c = System.out::println;
//		c.accept("");
//		
		//Function<String, Integer> f = city -> city.length();
		//System.out.println(f.apply("Pune"));
		
		
		
		
		
	}

}
