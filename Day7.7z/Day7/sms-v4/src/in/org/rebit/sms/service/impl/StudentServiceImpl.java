package in.org.rebit.sms.service.impl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.function.Predicate;
import java.util.stream.Stream;

import in.org.rebit.sms.dao.StudentDao;
import in.org.rebit.sms.entitiy.Student;
import in.org.rebit.sms.exception.StudentNotFoundException;
import in.org.rebit.sms.service.StudentService;

//This class handles business methods,business exceptions and transactions
public class StudentServiceImpl implements StudentService {

	// "Code To Interface" Approach
	private StudentDao studentDao;

	// constructor
	public StudentServiceImpl(StudentDao studentDao) {
		this.studentDao = studentDao;
	}

	@Override
	public Student registerStudent(Student s) {

		return studentDao.createStudent(s);
	}

	@Override
	public List<Student> getAllRegisteredStudents() {
		return studentDao.getAllStudents();
	}

	@Override
	public Student getRegisteredStudentByRollNumber(int rollNumber) throws StudentNotFoundException {

		Student foundStudent = studentDao.getStudentByRollNumber(rollNumber);
		
		if(foundStudent == null)
			throw new StudentNotFoundException(rollNumber);
		return foundStudent;
	}

	@Override
	public List<Student> getStudentsSortedByPercentage() {
		ArrayList<Student> sortedStudents = new ArrayList<>(studentDao.getAllStudents());
		Collections.sort(sortedStudents);
		return sortedStudents;
	}

	@Override
	public List<Student> getStudentsSortedByAttempts() {
		ArrayList<Student> sortedStudents = new ArrayList<>(studentDao.getAllStudents());
		Comparator<Student> comparator = new Comparator<Student>() {
			@Override
			public int compare(Student o1, Student o2) {
				return o1.getAttempts() - o2.getAttempts();
			}
		};

		Collections.sort(sortedStudents, comparator);
		return sortedStudents;
	}

	@Override
	public Student unregisterStudent(int rollNumber) {
		return studentDao.deleteStudentByRollNumber(rollNumber);

	}

	@Override
	public Student updateStudentByRollNumber(int rollNumber, Student student) {
		return studentDao.updateStudentByRollNumber(rollNumber, student);
	}
	
	private Stream<Student> getStudentStream(Predicate<Student> p)
	{
		return this.getAllRegisteredStudents()
		   .stream()
		   .filter(p);
	}
	
	@Override
	public List<Student> getAllStudentsNameStartsWith(String startsWith) {
		return this.getStudentStream(student -> student.getName().startsWith(startsWith))
				   .toList();
	}

	@Override
	public List<Student> getAllStudentsScoredMoreThan(double score) {

		return this.getStudentStream(student -> student.getPercentage() > score)
				   .toList();		
	}
	

	@Override
	public long findTotalStudensSocredMoreThan(double score) {
		return this.getStudentStream(student -> student.getPercentage() > score)
				   .count();
	}


	


	@Override
	public List<String> findNamesOfAllStudentsScoredMoreThan(double score) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Student> findAllStudentsLearningSubject(String subject) {
		return null;	   
	}



}
