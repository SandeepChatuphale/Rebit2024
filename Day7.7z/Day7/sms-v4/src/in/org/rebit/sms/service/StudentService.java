package in.org.rebit.sms.service;

import java.util.List;

import in.org.rebit.sms.entitiy.Student;
import in.org.rebit.sms.exception.StudentNotFoundException;

public interface StudentService {

	Student registerStudent(Student s);

	List<Student> getAllRegisteredStudents();

	Student getRegisteredStudentByRollNumber(int rollNumber) throws StudentNotFoundException;

	Student unregisterStudent(int rollNumber);

	
	Student updateStudentByRollNumber(int rollNumber, Student student);

	List<Student> getStudentsSortedByPercentage();

	List<Student> getStudentsSortedByAttempts();

	
	
	//find all students score more than 90
	List<Student> getAllStudentsScoredMoreThan(double score);

	//find count of total students who scored more than
	long findTotalStudensSocredMoreThan(double score);
	
	//find all students name starts with 
	List<Student> getAllStudentsNameStartsWith(String startsWith);
	
	//find all total students names who scored more than
	List<String> findNamesOfAllStudentsScoredMoreThan(double score);
	
	//find all the students learning a specific subject
	List<Student> findAllStudentsLearningSubject(String subject);
	
	//find count of students learning a specific subject
	
	//find total students learning more than 1 subject
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
