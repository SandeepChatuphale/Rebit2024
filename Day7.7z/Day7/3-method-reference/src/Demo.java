
public class Demo {

	static void display(String s) {
		//System.out.println("in display() " + s);
	}
	public static void main(String[] args) {
		PrintableFormat pf ;
//		pf = (String format) -> {System.out.println(format);};
//		pf.print("PDF");//call
//		
//		//specifying data to arguments is optional
//		pf = (format) -> {System.out.println(format);};
//		pf.print("HTML"); //call
//		
//		//() optional if there is ONLY ONE parameter
//		pf = format -> {System.out.println(format);};
//		pf.print("Excel"); //call
//		
//		//{} optional if there is ONLY ONE statement
//		pf = format -> System.out.println(format);
//		pf.print("Word"); //call
		
		pf = System.out::println;		//instance method reference
		//pf.print("using method reference");
		
		pf = Demo :: display; 			//static method reference
		pf.print("passing");
		
		
		//Taxable lambdas
		Taxable tax;
		tax = (double income)->{return income*0.20;};
		
		tax = (income) -> {return income*0.20;};
		
		tax = income -> {return income*0.20;};
		
		tax = income -> income*0.20;
		
		
		Calculate c ;
		c = (int a,int b) -> {return a + b;};
		c = ( a, b) -> {return a + b;};
		c = ( a, b) ->  a + b;
		//c = a, b ->  a + b;//
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
