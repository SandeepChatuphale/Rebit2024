
public interface PrintableFormat {

	void print(String type);
}
