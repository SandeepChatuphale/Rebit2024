import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class NeedOfStream {

	public static void main(String[] args) {
		
		List<String> cities = new ArrayList<>();	//source
		cities.add("Mumbai");
		cities.add("Pune");
		cities.add("Jaipur");
		cities.add("Kolkata");
		cities.add("Banglore");
		
		
		//this is imperative style of programming
		//how? and what?
		List<String> filteredList  = new ArrayList<>();//destination
		
		for (String city : cities) {		//iterating and applying some filter
			if(city.charAt(0) == 'M')
				filteredList.add(city);
		}
		
		System.out.println(cities);
		System.out.println(filteredList);
		//=================================================================
		
		
		//filtering cities by starts with a specific character
		//step 1
//		Stream<String> citiesStream = cities.stream();
//		
//		//step 2
//		Stream<String> filteredStream = citiesStream
//										.filter(city -> city.charAt(0) == 'M');
//		
//		//step 3
//		List<String> modifiedList = filteredStream.toList();//toList() was added in jdk 16
		
		//filter() to filter based on Predicate
		List<String> filterednewList = cities.stream()
											 .filter(city -> city.charAt(0) == 'M')
											 .toList();
		
	
		//counting total cities
		//Stream<String> sourceStream = cities.stream();
		//long citiesCount = sourceStream.count();//terminal operation
		
		long citiesCount =cities.stream()
								.count();
		
		//get length of each city name - and create list of the final result
		//create a list containing length of each city name
		
//		Stream<String> s = cities.stream();
//		//map() - is accepting lambda for Function functional interface
//		Stream<Integer> map = s.map(city -> city.length());
//		//List<Integer> list = map.toList();//added in jdk 16
//		List<Integer> list = map.collect(Collectors.toList());//present since jdk 8
//		System.out.println(list);
	
		//map() is used to transform data by applying Function
		List<Integer> list2 = cities.stream()
									.map(city -> city.length()) //accepting lambda for Function
									.toList();
			  
		
		//create a list containing length of each city name which length > 5
		List<Integer> list = cities.stream()
								   .filter(city -> city.length()>5)
								   .map(city -> city.length())
								   .toList();
		
		
		//OR
		cities.stream()
			   .map(city -> city.length())
			   .filter(cityNameLength -> cityNameLength>5)
			   .toList();
		
		
		
		
		
		
		
		
		
		
		
	}

}
